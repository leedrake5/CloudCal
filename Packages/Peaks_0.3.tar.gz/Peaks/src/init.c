/*
 * Native routine registration for Peaks package
 * Required for R >= 3.4.0 CRAN compliance
 */

#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

/* Declarations of C functions called from R */
extern SEXP R_SpectrumBackground(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP R_SpectrumSmoothMarkov(SEXP, SEXP);
extern SEXP R_SpectrumDeconvolution(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP R_SpectrumDeconvolutionRL(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP R_SpectrumSearchHighRes(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);

/* Registration table for .Call routines */
static const R_CallMethodDef CallEntries[] = {
    {"R_SpectrumBackground",      (DL_FUNC) &R_SpectrumBackground,      7},
    {"R_SpectrumSmoothMarkov",    (DL_FUNC) &R_SpectrumSmoothMarkov,    2},
    {"R_SpectrumDeconvolution",   (DL_FUNC) &R_SpectrumDeconvolution,   5},
    {"R_SpectrumDeconvolutionRL", (DL_FUNC) &R_SpectrumDeconvolutionRL, 5},
    {"R_SpectrumSearchHighRes",   (DL_FUNC) &R_SpectrumSearchHighRes,   7},
    {NULL, NULL, 0}
};

/* Package initialization */
void R_init_Peaks(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
