# xrftools — Physics & Computational Review for Wide-Energy-Range Generalization (SEM-EDS <30 keV → ~100 keV K-lines)

> **Implementation status (2026-07-15): the entire roadmap (#1–#23) is implemented and tested**
> (239 passing tests). Physics: double-ω fix, cross-section excitation weighting
> (`excitation_weighting`), Coster-Kronig L-cascade (`coster_kronig`), energy-dependent σ(E)
> resolution, detector efficiency (`efficiency`), escape peaks (`escape`), Rayleigh/Compton scatter
> (via `tube`/`geometry`), heavy-element M-lines (Z 50–92, EADL97), electron-impact excitation
> (`excitation="electron"`), Hypermet tail/shelf line shape (`tail`/`step`/`beta`,
> `xrf_lineshape`), and sum/pile-up peaks (`sum_peaks`). Numerics: NNLS non-negativity,
> Poisson/weighted fit, count-space chi_sq, rank/condition diagnostics (`condition_number`,
> aliased→NA), windowed + cached template build (`cache_templates`), energy-calibration refinement
> (`refine_calibration`), energy-aware SNIP (`energy_aware`), RMS `discreteFilter` convergence, and
> generic channel→energy ingestion. Quantification: `xrf_compton_normalize`, `xrf_fp_sensitivity`,
> `xrf_quantify` (first-order fundamental parameters with self-absorption). Conditions are flat
> scalar args (`detector_type`, `fano`, `epsilon_ev`, `noise_fwhm_ev`, `efficiency`, `escape`,
> `excitation`, `tail`/`step`/`beta`, ...) plus `xrf_tube()`/`xrf_geometry()`.
>
> **Post-roadmap enhancements (2026-07-15, 255 tests):** (E1) Gryzinski (1965) electron-impact
> cross section (`method="gryzinski"` default, better near-threshold shape than Bethe); (E2)
> first-order secondary/enhancement fluorescence in the FP quant (`secondary_fluorescence=TRUE`,
> Shiraiwa-Fujino); (E3) true two-pass pile-up with physically-fixed coincidence amplitudes
> (`pileup_tau`); (E4) rebuilt `x_ray_cross_sections` from the full EPDL97 source — all subshells
> K-M5, native grid ~5 eV to 200 keV — plus a new `x_ray_mass_attenuation` table (photoelectric/
> Rayleigh/Compton/total). E4 **removed** three earlier approximations: the M4/M5→M3 proxy, the
> >100 keV extrapolation, and the sub-5 keV efficiency limitation (window absorption is now computed
> from real data with total attenuation — correctly showing that an 8 um Be window blocks O K-alpha).
>
> **Follow-up limit-fixes (2026-07-15, 267 tests):** (L1) relativistic correction to the electron
> cross section (`relativistic=TRUE`, extends validity toward TEM energies) with an extensible
> `method` arg for future Bote-Salvat coefficients; (L2) Ebel (2001) X-ray-tube spectrum model
> (`xrf_tube_spectrum`) with polychromatic FP excitation — pass `tube=` to `xrf_quantify` /
> `xrf_fp_sensitivity` to integrate excitation over the continuum + anode lines instead of a single
> energy; (L3) opt-in oxide stoichiometry (`oxide=TRUE`, default FALSE — XRF cannot measure O, so
> oxygen-by-difference is a modelling choice) that computes O from cation oxides and includes it in
> the matrix.
>
> **Final additions (2026-07-15, 277 tests):** (1) **Bote & Salvat (2008)** electron-impact
> ionization cross sections are now the DEFAULT electron method (`method="bote-salvat"`) -- an exact
> port of the public-domain NIST BoteSalvatICX.jl, with the full Z=1-99 / K-M5 coefficient database
> vendored as `x_ray_bote_salvat` (returns absolute cm^2, intrinsically relativistic); Gryzinski and
> Bethe remain selectable. (2) **Tertiary fluorescence** (`tertiary_fluorescence = TRUE`) via an
> enhancement-matrix formulation B(C(1+BC)), capturing the k->j->i chain (a ~1\% correction on top
> of secondary).
>
> _Genuinely remaining:_ only empirical validation/calibration of the full FP chain against
> certified reference materials -- a measurement exercise, not a code gap.

## 1. Executive summary

xrftools is a photon-XRF deconvolution package whose entire physics and numerics are hard-tuned to one operating point: a handheld tube at mid energy (~5–20 keV), a Si detector at a single fixed resolution, K/L lines of mid-Z elements, and a near-ideal calibration. Almost every physical quantity that *should* vary with energy is a constant or is missing: detector resolution is a scalar `sigma = 0.07 keV` (FWHM 165 eV) applied to every line at every energy; excitation is a boolean step `edge_kev <= beam_energy_kev` with no cross-section, no bremsstrahlung continuum, and no electron-impact model; relative line intensities are a beam-independent absorption-jump proxy that additionally **double-counts the fluorescence yield**; there is no detector efficiency, no escape/sum/tail peaks, no Rayleigh/Compton scatter templates, and no matrix correction. The fit itself is unweighted, unconstrained OLS (so it returns negative concentrations), rebuilds an identical dense template matrix per spectrum, and reports a `chi_sq` that is NaN/Inf on every real spectrum. The good news: much of the needed atomic data is *already in the package but unused* (`x_ray_cross_sections` with per-subshell photoionization K–M3 to 100 keV; Coster-Kronig f-values; fluorescence yields M1–M5; EADL97 M-shell radiative rates vendored in `data-raw/`), and the detector metadata (Fano, Noise, Gain, Zero, TubeAnode, DeadTime) is already parsed — none of it is wired into the fit. Two gaps are true feature-additions (an electron-excitation mode; M-line + light-element line energies), but the majority are wiring existing data through corrected formulas. **Bottom line:** the mid-energy handheld path is usable but has real correctness bugs (double-omega, negative amplitudes, broken chi_sq); the wide-range goal is blocked primarily by the constant-resolution model, the missing excitation/efficiency energy-dependence, the absent M-lines/light-element energies, and the unmodeled scatter — all fixable, mostly by activating data already shipped.

---

## 2. The core generalization blockers

These are the assumptions wired for the ~5–20 keV Si-handheld window that break at one or both ends of the target range.

### 2.1 Constant detector resolution `sigma = 0.07 keV`
**Assumption.** `R/deconvolution.R:20,46` set `default_sigma = 0.07 keV`; `gaussian_fun` (`:278-280`) is a bare Gaussian; every peak of every element at every energy gets this one width. `xrf_energies()` (`R/physics.R:162`) emits no `sigma` column, so nothing overrides it.

**Why it breaks.** Semiconductor resolution is energy-dependent: FWHM(E) = 2.3548·√(σ_noise² + F·ε·E), σ in eV². For a Si detector (σ_noise≈36 eV, F≈0.115, ε≈3.64–3.66 eV):

| E (keV) | true FWHM | code FWHM 165 eV is… |
|---|---|---|
| 0.3 (C-ish) | ~89 eV | ~85% too **wide** |
| 1.0 (Na Kα) | ~98 eV | ~68% too wide |
| 6 (Fe) | ~148 eV | ~12% too wide (the sweet spot) |
| 17.4 (Mo Kα) | ~223 eV | ~26% too **narrow** |
| 60 | ~392 eV | ~137% too narrow |
| 98 (U Kα) | ~496 eV | ~3× too narrow |

Too-narrow templates at high keV cannot absorb the true peak counts (residual splits into neighbors → false elements, biased areas); too-wide templates at sub-keV smear adjacent light-element lines into one blob.

**Fix.** Add a resolution model and populate `peaks$sigma` per line. Note the pmap at `:105-108` **already consumes a per-row `sigma`** — you only need to fill the column, not restructure. Correct dimensionally-consistent form (a common transcription error is to divide the whole thing by 2.3548 — that under-scales the Fano term 5.5×):

```r
detector_sigma_kev <- function(E_kev, noise_ev, fano, eps_ev) {
  sqrt(noise_ev^2 + fano * eps_ev * (E_kev * 1000)) / 2.3548 / 1000  # noise_ev is a SIGMA in eV
}
```
Seed `noise_ev`/`fano` from `NoiseReference`/`FanoReference` (`R/read_spectra.R:142-151`), `eps` from the parsed `Detector` string (Si 3.64–3.66 eV, Ge 2.96 eV, CdTe ~4.43 eV). Keep `0.07` only as a fallback. Effort: **medium**.

### 2.2 Step-function excitation `edge_kev <= beam_energy_kev` with beam-independent intensities
**Assumption.** A single scalar `beam_energy_kev` is both the tube endpoint and the sole on/off gate for a line (`R/physics.R:176`). `xrf_relative_peak_intensity` (`:142-146`) accepts `beam_energy_kev` but **never uses it** — the argument dead-ends. The energy-resolved `x_ray_cross_sections` table (K,L1,L2,L3,M1–M3; 0–100 keV; Z 1–100) is loaded (`R/data.R:46`) and referenced **nowhere** in code.

**Why it breaks.** (a) A real tube emits a bremsstrahlung continuum N(E) ∝ (E_max−E)/E up to E_max plus characteristic lines; an edge just below E_max is barely excited (few photons above it, flux → 0 at E_max). The step model snaps such lines fully ON — e.g. Pb K at a 90 kV tube (K edge 88 keV) is turned on at full jump-ratio strength although almost no photons exist above 88 keV. (b) Far above an edge σ_shell has fallen ~E⁻³, ignored. (c) The K:L branching is *frozen* regardless of E0: for Pb, σ_K/σ_L3 ≈ 19 at 90 keV and ≈ 21 at 100 keV from the table, and σ_K is undefined below the 88 keV K edge — the code assigns the same ratio everywhere. This mis-weights every multi-shell element (all Z ≳ 47 where K and L coexist at high keV).

**Fix.** Make `beam_energy_kev` live by **replacing** the absorption-jump factor with the per-subshell photoionization cross section σ_shell(E0) interpolated (log-log, on the 5-keV grid, 0/NA below the edge) from `x_ray_cross_sections`. Critically, do **not** multiply σ *alongside* the jump ratio — the table already holds the partial (per-subshell) cross sections, and (r−1)/r is merely an alternative device for the same subshell split, so keeping both double-counts. Primary-fluorescence relative intensity is
> I(trans) ∝ σ_subshell(E0) · ω_subshell · branching.

For a polychromatic tube the proper weight is w(edge)=∫_edge^{E_max} σ_shell(E)·N(E) dE with Kramers N(E); even the single-energy σ_shell(E0) is a large correctness gain. Separate two parameters — `tube_kv` (endpoint / N(E)) vs. excitation weighting — and retire the README `kV*0.75` magic number (`README.md:101`), which is a Z-independent window bound, not an excitation weight. Effort: medium (single-energy) to high (spectrum integral).

### 2.3 M-lines and light-element (Z<10) line energies are absent — heavy elements invisible below their L edge, and O/C/N/F unrepresentable
**Assumption / gap.** `x_ray_xrf_energies` covers Z 10–92 with edges K/L1/L2/L3 only. There are **zero M-initial transitions** anywhere in the pipeline — not in `x_ray_xrf_energies`, nor in the NIST source `x_ray_energies`, nor in `x_ray_emission_probabilities` (72 unique trans, all K/L). Light elements start at Ne (Z=10); C/N/O/F have **no energy rows**. (Correction to an earlier framing: the `^([KL][0-9]?)` regex at `data-raw/xrf_energies.R:21` is a downstream edge-label extractor — broadening it alone does nothing; the M transitions and Z=3–9 rows must actually be *added* to the source data.)

**Why it breaks.** For SEM-EDS / low-kV handheld, a <30 keV beam often cannot reach the L3 edge of heavy elements (Au 11.92, Pb 13.04, U 17.17 keV) and never the K edge — so the M-series at 2–3.5 keV (Au Mα 2.12, Pb Mα 2.34, U Mα 3.17 keV) is the only signal, and the package cannot represent it: `xrf_energies()` returns nothing for Au/Pt/Pb/Hg/Bi/Th/U below ~13 keV. Equally, light-element K-lines (C 0.277, N 0.392, O 0.525, F 0.677 keV) are the backbone of SEM-EDS/mineralogy (O is ubiquitous) and are entirely missing. This is a hard, total blocker for the electron/low-energy regime.

**Fix.**
- **Light elements (cheap — pure energy gap):** the yield and emission-probability rows for Z=6–9 already exist (C K yield 0.00168; C KL2/KL3 emission probs present) — `xrf_relative_peak_intensity("C","K","KL3")` already returns a value. Add only the K-edge + KL2/KL3 **energy** rows (C 0.277, N 0.392, O 0.525, F ~0.685 keV; edges C 0.284, N 0.402, O 0.532, F ~0.685) to `x_ray_energies` and rebuild. Effort: medium.
- **M-lines (real data addition):** import M-shell line energies + radiative rates for Z≥57. The **EADL97 M-shell radiative-rate data (`data-raw/EADL97_MShellRadiativeRates.dat`, M1–M5) and M-subshell binding energies (`EADL97_BindingEnergies.dat`) are already vendored** in the repo — build Mα1,2 (M5-N6,7), Mβ (M4-N6), Mγ (M3-N5), Mζ from them without pulling in xraylib. Add M4/M5 edges to the edge join. Note `x_ray_cross_sections` stops at M3, so Mα/Mβ production must map onto M3 σ as an interim (or extend the table to M4/M5). Effort: high.

### 2.4 No electron-impact excitation model (SEM-EDS)
**Assumption.** Every intensity term assumes photon excitation (absorption jump ratio, edge-≤-beam cut). There is no excitation-mode switch. Pointed at SEM-EDS data it silently reuses photoionization physics.

**Why it breaks.** Electron-impact ionization is a different process: vacancy production scales with the ionization cross section Q_shell(E0) as a function of overvoltage U = E0/E_c, rising from zero at U=1, peaking at U≈3–5, then declining — there is no jump ratio for electrons. The hard cut edge≤beam is wrong (useful excitation needs U ≳ 1.2–1.5), and K:L / K:M ratios follow Q_shell ratios, not σ_photo ratios. φ(ρz) depth distribution + self-absorption govern emergent intensities.

**Fix.** Add `excitation = c('photon','electron')` threaded from `xrf_energies` into `xrf_relative_peak_intensity`. For electron: replace the edge cut with an overvoltage cut U>U_min, and replace the shell-production term with `xrf_electron_ionization_cross_section(element, shell, E0)` implementing **Bote-Salvat (2008)** (PENELOPE/DTSA-II) or **Casnati (1982)**. Keep `transition_probability` and `fluorescence_yield` unchanged (relaxation is independent of how the vacancy was made). Document φ(ρz)/self-absorption as out of scope for relative-intensity templating. Effort: high. (See §5.)

### 2.5 Fixed-channel SNIP window ignores energy-dependent peak width
**Assumption.** `xrf_add_baseline_snip` passes a scalar `iterations` (README uses 20) straight to `Peaks::SpectrumBackground` — a clipping window constant in **channels** across the whole spectrum.

**Why it breaks.** SNIP removes anything narrower than its half-window (~1× local FWHM). But FWHM grows ~2.7× from 6→60 keV (143→383 eV) and ~485 eV at 98 keV, so a peak spans ~2.7× more channels at 60 keV than at 6 keV. One fixed window can be right at only one energy: tuned low it climbs into the wings of wide high-keV K-lines (subtracts real signal, areas biased low); tuned high it washes light-element/L/M multiplets into the background.

**Fix.** Make the window energy-aware from the resolution model (§2.1): either run SNIP blockwise with per-band FWHM-in-channels, or resample onto a √E abscissa where width is constant, SNIP with a fixed window, map back. Expose and default the improved options `decreasing=TRUE`, `order=4–6` (for the broad Compton hump). Effort: medium.

### 2.6 Calibration assumed exact; energy axis vendor-supplied
**Assumption.** Template centroids come verbatim from the peak table; there is no gain/zero refinement, and `Zero/Gain/Fit` references parsed from the meta are unused. The reader relies on a pre-baked `Energy (keV)` column (`R/read_spectra.R:86-98`); `validate_spectra` hard-requires it.

**Why it breaks.** Amplitude LS is exquisitely sensitive to centroid offset because templates are nonlinear in μ: a δ=30 eV drift on a 10⁴-count peak with σ=70 eV yields a derivative-shaped residual of order 10³ counts (peak ≈0.607·A·δ/σ), dwarfing nearby trace peaks and leaking into every overlapping template under OLS. Pure gain error grows linearly with E — a 0.1% gain error at U Kα (98 keV) = 98 eV > σ. This is *the* wide-range generalization blocker for a single static calibration spanning sub-keV to 100 keV, and also blocks non-Panalytical ingestion entirely (SEM-EDS vendors ship counts-vs-channel + gain/zero, not an energy column).

**Fix.** (a) Add a calibration-refinement outer loop: variable-projection separable LS alternating a constrained amplitude solve with a 2-parameter Gauss-Newton refine of (zero, gain), Jacobian columns dtemplate/dμ = template·(E−μ)/σ². (b) Add vendor-neutral `xrf_calibrate_energy(channel, zero, gain, quad=0)` and a generic reader; when no energy column is present, compute it from **GainFit/ZeroFit** (verified: the shipped file's axis is E = ZeroFit + GainFit·channel; the *Reference* pair is ~3 eV off). Document keV/channel vs eV/channel to avoid a 1000× error. Effort: high (refinement), low (ingestion).

---

## 3. Physics improvements (all energies), ranked

### 3.1 [correctness bug, HIGH] Drop the double-counted fluorescence yield
`xrf_relative_peak_intensity` (`R/physics.R:142-146`) returns `jump_ratio · transition_probability · fluorescence_yield`. But `xrf_transition_probability` reads `x_ray_emission_probabilities`, whose values are **already ω·branching**, not branching normalized to 1. Verified: per-shell sums of emission_probability equal the fluorescence-yield table (Au K 0.9590 vs ω_K 0.96128; L2 0.36271 vs 0.36326; L3 0.31834 vs 0.31946; also Pb, Fe), and the `TOTAL` rows match. Multiplying by ω again applies it twice. Within a shell ω is constant (intra-shell pattern unaffected), but ω varies strongly *between* shells (Au ω_K 0.96, ω_L3 0.32, ω_L1 0.082), so every cross-shell ratio is distorted by ω_K/ω_L3≈3× and ω_L3/ω_L1≈3.9× — corrupting any multi-shell template (heavy elements at high keV with K+L both in window; L1-vs-L3 sub-ratios in handheld).

**Fix.** `relative intensity = jump_ratio · emission_probability` (drop the ω factor). Add a unit test asserting Σ_trans(rel_int within shell)/jump_ratio == fluorescence_yield for **K/L2/L3** (assert L1 only with tolerance — L1 identity breaks by ~4× due to Coster-Kronig, Fe L1 sum 0.00147 vs fy 0.00035). Effort: **low** (one-line). Pairs with §3.4/§2.2: when switching to cross-section weights, use branching = emission_probability/ω to avoid re-introducing double-count.

### 3.2 [HIGH] Detector efficiency / window / dead-layer response
Template amplitudes carry no eff(E); no window, dead-layer, or active-thickness term exists. Counts recorded per emitted photon = emitted · eff(E), eff(E) = exp(−μ_window ρ t_win)·exp(−μ_dead ρ t_dead)·(1−exp(−μ_active ρ t_active)). Strongly energy-dependent at both ends: an 8 µm Be window transmits only ~55–65% at O Kα (0.525 keV); a **450 µm** modern SDD (not 3–5 mm — that's Si(Li)/Ge) is ~13% efficient at 60 keV and ~2.6% at 100 keV (recomputed from the packaged Si photoelectric σ), so heavy-element K-lines are grossly underweighted vs their L-lines.

**Fix.** Build eff(E) from mass-attenuation coefficients. Crucially, the **active-layer term must use the photoelectric cross section, not total μ** (Compton events don't land in the photopeak) — `x_ray_cross_sections` is photoelectric-per-subshell, exactly right; the window term may use total μ. Apply eff(E) to absolute line intensities **before** the per-element normalization at `deconvolution.R:90-97` (applying it only at the gaussian build at `:105-108` lets the normalization partly cancel the shape correction). Because each element is one free coefficient, a uniform per-element scale is absorbed by the fit — eff(E) matters for (a) intra-element line **shape** (Kα/Kβ, K-vs-L) and (b) quantification (coef→concentration). Effort: high.

### 3.3 [HIGH] Escape peaks — Si/Ge/CdTe self-fluorescence
No escape satellite exists in X (`deconvolution.R:120`). Si escapes at E−1.740 keV (~1% near 2–4 keV); **Ge at E−9.886/−10.98 keV (up to ~10–15% just above the 11.10 keV Ge K edge); CdTe at E−23.17/−26.1/−27.47/−31.0 keV** with large fractions — a 10% escape fit as a real element is a first-order quant error and false-positive generator, precisely in the Ge/CdTe high-keV regime.

**Fix.** Inject an escape Gaussian into the *same element column* (tied to the same coefficient, no free parameter) at E_i − E_esc,j for each parent line with E_i above the detector K edge. **Corrected escape-probability formula** (the intuitive form is easy to invert):
> f = 0.5·ω_K·(1 − 1/r)·[1 − (μ_esc/μ_i)·ln(1 + μ_i/μ_esc)]

with μ_i = detector attenuation at the **incident** (parent-line) energy, μ_esc at the **escape-line** energy. Just above the edge μ_i ≫ μ_esc so the bracket → 1 (escape maximal at the edge, as observed); the inverted form (μ_i/μ_esc)·ln(1+μ_esc/μ_i) wrongly → 0 there. Key off the parsed `Detector` string; gate on the K-edge condition to avoid spurious low-energy columns. Effort: high (medium for Si-only).

### 3.4 [HIGH] Beam-energy-dependent cross sections + Coster-Kronig L-subshell redistribution
Two coupled activations of already-shipped data (see §2.2 for the cross-section replacement).

**Coster-Kronig.** `x_ray_coster_kronig_probabilities` (f12/f13/f23, Z 11–100) is cached (`R/zzz.R:20-22`) and `xrf_coster_kronig_probability` (`:125-138`) reads it, but **nothing calls it**. CK transfers primary L1/L2 vacancies down before emission; using the package's own EADL97 values (Au f12=0.070, f13=0.701, f23=0.128 — f13 much larger than Krause, so the effect is *stronger* than folklore), the effective radiative populations are:
> V1_eff = V1  (not reduced — CK loss already in ω1's normalization; verified Σ Au L1 emission = 0.0825 = ω_L1)
> V2_eff = V2 + f12·V1
> V3_eff = V3 + f23·V2_eff + f13·V1

Ignoring CK overweights L1-fed lines (Lβ3 L1M3, Lβ4, Lγ2,3) and underweights the dominant L3-fed Lα1,2 (L3M4,5), Lβ2 (L3N5) and L2-fed Lβ1 — by tens of percent, biasing Pb/Au/W/U L-family templates (handheld L-only and high-keV).

**Fix (combined).** In `xrf_relative_peak_intensity`, first assemble primary subshell vacancies n_i (from σ_shell(E0), §2.2), apply the CK cascade above, then multiply each subshell's effective vacancy count by its **branching ratio = emission_probability/ω** (using the §3.1 fix). This is a per-element grouping step, not a single multiplicative factor. Effort: medium.

### 3.5 [CRITICAL] Rayleigh & Compton tube-scatter templates
The two largest features in a real spectrum — coherent (Rayleigh) tube-line peak and incoherent (Compton) peak — have **no template**; SNIP is expected to swallow them. `TubeAnode`/`kV` (`read_spectra.R:132,134`) are parsed but unused. The Compton peak is *not* at the tube-line energy:
> E_c = E / (1 + (E/511)(1 − cos θ))

At θ≈150°: Rh Kα 20.2→18.8 keV (ΔE 1.4); 59.5→48.9 (ΔE 10.6); 98.4→72.4 (ΔE 26). It is Doppler-broadened to ~1.5–3× detector FWHM and asymmetric — SNIP with a fixed narrow window cannot remove it, so the fit assigns the residual bump to whatever element sits under the Compton hump (false positives), or a large window digs a trough.

**Fix.** Add explicit scatter columns to X before the cbind: Rayleigh = detector-σ Gaussian at each tube characteristic line (Rh/Ag/W/Mo/Au) for the parsed anode; Compton = broadened, optionally asymmetric Gaussian at E_c with σ_compton = √(σ_det² + σ_doppler²), scatter angle θ (default ~120–150°). Fit their (non-negative) amplitudes jointly. Keep SNIP for the smooth bremsstrahlung only. Effort: high.

### 3.6 [MEDIUM] Non-Gaussian lineshape (low-energy tail / ICC shelf)
`gaussian_fun` is a bare symmetric Gaussian; real semiconductor lineshapes have a low-energy exponential tail + flat shelf from incomplete charge collection (Hypermet). The tail carries a few % to >10% of counts, growing toward low E and for CdTe hole-tailing at high E; a pure Gaussian leaves low-side residuals the unconstrained LS reassigns to lower-energy neighbors and undercounts area.

**Fix.** Hypermet profile: G(E) + step·erfc((E−μ)/(√2σ))/2 + tail·exp((E−μ)/β)·erfc((E−μ)/(√2σ) + σ/(√2β)); default tail=step=0 to preserve current handheld behavior, enable via detector config. Base R has no `erfc` — use erfc(x)=2·pnorm(−x·√2). Update the area integral (`:207`) to include tail+step. Effort: high.

### 3.7 [MEDIUM] Sum/pile-up peaks at E_i+E_j
Only single-photon photopeaks in X; `DeadTime/DeadTimePct/OutputCounts/FastChanCounts` (`read_spectra.R:167-173`) parsed but unused. Pileup fraction ~R·τ; 2× a ~10 keV line lands on ~20 keV trace K-lines → false positives at high rate. Note a strictly linear LS cannot carry a template whose amplitude is a product of two other unknown coefficients — implement as a two-pass scheme (fit → estimate strong-line areas → add fixed-amplitude sum templates → refit), gated on `DeadTimePct`. Minimal fallback: flag likely sum-peak channels. Effort: high.

### 3.8 [CRITICAL] Quantification: no matrix / self-absorption / FP layer
The pipeline stops at net `peak_area = height·primary_sigma·√(2π)` (`:207-208`), and the README (`:113-119`) regresses raw area against certified concentration. Measured I_i = C_i·S_i(E)·M_i(sample): S_i lumps fundamental sensitivity (jump, yield, transition, excitation, efficiency, geometry) and M_i is matrix absorption-enhancement, which varies by factors of several between silicate and Fe-/Pb-rich matrices (low-E lines hit hardest as μ rises steeply with decreasing E). A single area-vs-concentration calibration is valid only within one near-identical matrix and one energy region. Also note **only the primary line's area is reported** — elements with strong Kβ / L-families (up to 20–30%) are systematically undercounted.

**Fix (two tiers).** (1) **Compton normalization** (cheap, matrix-robust): once the Compton peak is fitted (§3.5), divide each element net area by the Compton area — cancels much of the matrix effect for mid-Z analytes; the standard handheld normalizer. (2) **Fundamental parameters:** wire the unused `x_ray_cross_sections` + physics tables to compute S_i(E), add an Ebel tube-spectrum + detector efficiency, and solve the Sherman equation iteratively (self-absorption + first-order secondary fluorescence) with a mass-absorption sum over the fitted composition. Note physics.R has **no MAC function** yet — FP needs a mass-attenuation data source added. Also fix `peak_area` to integrate the full multi-line template: A_template = Σ_i rel_height_i·σ_i(E_i)·√(2π), `peak_area = coef·A_template`. At minimum, document that peak_area is uncalibrated intensity and expose a matrix-correction hook. Effort: high.

---

## 4. Computational / numerical improvements, ranked

### 4.1 [CRITICAL] Non-negative least squares
`qr.coef` (`:130`) / `lm(~0+.)` (`:179`) are unconstrained; only NA (rank-deficient) coefficients are zeroed (`:131`). Overlapping templates (S Kα 2.307 / Pb Mα 2.342 / Mo Lα 2.293; As Kα 10.543 / Pb Lα 10.551 keV) make X near-collinear and OLS trades a spurious negative amplitude on one element for extra positive on its neighbor → **negative concentrations** (`peak_area = height·σ·√2π` inherits the sign). The README's own components plot drops 4504 rows to "NaNs produced" under `scale_y_sqrt` — a direct symptom of negative fitted responses. X is provably non-negative, so the only source of a negative component is a negative coefficient.

**Fix.** `nnls::nnls(X, response)$x` (Lawson-Hanson active-set; note the code is *unweighted* OLS today, so it's `nnls(X, response)`, add `sqrt(w)` only when WLS lands). NNLS also cleanly zeros truly-absent elements (better detection limits). Derive SEs from the covariance of the active (nonzero) set; SE=0/NA with a 'clamped' flag for pinned coefficients. Add `nnls` to DESCRIPTION Imports (currently absent, but installed). Effort: medium.

### 4.2 [HIGH] Poisson / weighted least squares on counts
Both branches minimize unweighted SSR on baseline-subtracted cps. Spectra are Poisson: var(cps)=gross_cps/t, spanning 0 to 10⁵+ across a spectrum (10× noise ratio between a 10⁴ and 10² cps peak). OLS is inefficient (**correction: not biased** — under a correct model OLS stays unbiased/Gauss-Markov; motivate WLS as a precision/leverage gain, not a bias fix; the "negative-trace artifact" is from unconstrained amplitudes + model mismatch, addressed by §4.1). The homoscedastic pooled σ²=SSR/(n−rank) mis-scales *every* SE, so `height_se`/`peak_area_se`/LODs are quantitatively wrong. The code even already computes a Poisson-weighted `chi_sq` diagnostic but doesn't weight the fit.

**Fix.** WLS with w_i = t/gross_cps_i (≈1/counts); prefer model-based IRLS weights w=1/max(model_counts,1) (2–3 iterations) over Neyman data-weights to avoid the zero-count bias. QR path: `Xw=√w·X`, `yw=√w·response`, `qr.coef(qr(Xw), yw)`; for a correctly-weighted Poisson fit expected reduced χ²=1, so cov=(XwᵀXw)⁻¹ directly. lm path: `weights=w`. Requires threading raw counts (available, `read_spectra.R:95,97`) + livetime into the fitter (same plumbing as §4.4). Effort: medium.

### 4.3 [MEDIUM] chi_sq is NaN/Inf and dimensionally wrong
`chi_sq = sum(residuals²/response)` (`:158`, `:190`) divides by baseline-subtracted cps. The shipped .mp2 begins with hundreds of Counts=0 channels → response=0 → 0/0=NaN or resid/0=Inf poisons the whole sum; over-subtracted channels give negative terms. It's the Neyman form (divide by observation, undefined at 0) and omits the livetime factor. **Diagnostic-only** — does not affect coefficients/areas/SEs (those use the correct σ²=SSres/(n−rank)) — hence medium, not high.

**Fix.** Pearson reduced χ² dividing by the **model**, in count space: μ_i=(baseline+fit)·t, `chi_sq = Σ(N_i−μ_i)²/max(μ_i,1)/(n−rank)`. Never divide by measured value. (The trivial guard `valid<-response>0` is implementable in-place; the correct fix needs the counts+livetime plumbing of §4.2.) Effort: low–medium.

### 4.4 [HIGH] Generic channel→energy calibration ingestion
See §2.6. `xrf_calibrate_energy(channel, zero, gain, quad=0)` + generic counts+calibration reader; Panalytical fallback computes energy from **GainFit/ZeroFit** (Fit→Init→Reference order) when no energy column exists. Unblocks all non-Panalytical / SEM-EDS vendors. Effort: **low**.

### 4.5 [HIGH] Cache the template matrix + QR across a batch
`xrf_add_deconvolution_fun` (`:236-245`) maps the solver per spectrum; each call re-runs the group_by/normalize pipeline, re-evaluates every element's Gaussian over the full grid, rebuilds dense X, and recomputes `qr(X)` (~2np²−⅔p³ ≈ 7.4e6–5.2e7 flops for n=4096, p=30–80). For a batch from one instrument, X and its QR are **identical** — only the RHS `response` changes.

**Fix.** Split into a memoized template builder (keyed on hash of energy grid + peaks + sigma) returning {X, qr_X}, and a per-spectrum solver consuming only `response` (`qr.coef`/`qr.fitted`, O(np)). Memoize the whole template (normalize→X→qr), not just qr; fall back to per-row rebuild only if energy grids differ across rows. Effort: medium.

### 4.6 [MEDIUM] Sparse / windowed template construction
`gaussian_fun` evaluates exp() over all 4096 channels per line; dense n×p X (~2.6 MB/spectrum at p=80 — note ~98% zeros, since a ±6σ window at σ=0.07 keV, ~0.01 keV/ch is ~84 channels). Build each column only on [μ−6σ, μ+6σ] via `findInterval`, assemble `Matrix::sparseMatrix` (dgCMatrix), sparse QR/Cholesky. Note per-element columns are multi-band (Kα/Kβ, L-lines, escapes) so a true banded solver doesn't apply — use sparse. The real win is avoiding exp() over the full grid and dense QR, scaling to 8k–16k-channel SDD spectra. Effort: medium.

### 4.7 [MEDIUM] Rank-deficiency / collinearity diagnostics
`coef[is.na(coef)]<-0` (`:131`) silently zeros pivoted-out columns with no warning; the aliased element is reported as a confident 0. **Correction:** R's default `qr()` (LINPACK tol 1e-7) only declares rank-deficiency for essentially-identical columns (corr > 1−5e-15) — the flagship Pb/As overlap (8 eV, corr 0.9967, κ(XᵀX)≈645) stays **full rank** and is recovered, so this NA path is rarely hit; the real risk is *ill-conditioned but full-rank* fits with inflated, over-attributed coefficients (VIF≈154, ~12× SE inflation) reported with no diagnostic. Fix: warn on `qr_X$rank<ncol(X)` naming aliased elements and set their height/area to **NA not 0** (the lm path already returns NA — branches are inconsistent); report κ(XᵀX) as a fit diagnostic; optional Tikhonov ridge for genuinely inseparable pairs. NNLS (§4.1) + energy-dependent σ (§2.1) reduce spurious collinearity. Effort: medium. Severity low for the specific NA bug.

### 4.8 [LOW] `discreteFilter.cpp` convergence metric + smoothing guidance
`meanResidual = Σ(outNext−out)/n` (`src/discreteFilter.cpp:61-62`) is the **signed** mean change (~0.0006 vs true mean-abs 0.376 after one pass) for an area-preserving filter, so any positive epsilon fires on iteration 1 (premature early-exit, not "never"). Dormant by default (epsilon=−1). Fix: use RMS `√(Σ(outNext−out)²/n)` or mean-abs `Σ|outNext−out|/n`. Separately, document that deconvolution must fit **raw (unsmoothed)** cps with Poisson weights — smoothing correlates noise and deflates σ²/coef_se/chi_sq (false positives); the `smooth` column is for display/peak-finding only (currently opt-in, not auto-fed). Effort: low.

---

## 5. SEM-EDS (electron excitation) note

Electron excitation is not a parameter tweak on photon XRF — it replaces the vacancy-production physics at the front of the chain, while leaving the relaxation physics (transition probabilities, fluorescence yields, Coster-Kronig) unchanged. Three things are fundamentally different. **(1) Ionization mechanism.** Photon XRF partitions total photoabsorption into subshells via the absorption-jump ratio / partial photoelectric cross section; electrons ionize via an impact cross section Q_shell(E0) governed by overvoltage U=E0/E_c — zero at threshold U=1, peaking at U≈3–5, then slowly declining. There is no jump ratio and no sharp edge cut: useful excitation needs U ≳ 1.2–1.5, and K:L:M branching follows Q_shell(E0) ratios, not σ_photo ratios. Implement **Bote-Salvat (2008)** (as in PENELOPE/DTSA-II) or **Casnati (1982)** as `xrf_electron_ionization_cross_section(element, shell, E0)`. **(2) Analytical lines.** A <30 keV beam typically cannot reach heavy-element L edges and never K edges, so the **M-series (2–3.5 keV) is the primary signal** — this is unusable until M-line energies/branching are added (§2.3, data already vendored in `data-raw/EADL97_*`). Light-element K-lines (C/N/O/F, 0.25–1.1 keV) dominate and are also missing energies. **(3) Depth/matrix.** Emergent intensities are shaped by the φ(ρz) depth-ionization distribution and strong self-absorption (electrons deposit energy in depth; low-E lines are heavily reabsorbed) — quantitative EDS needs a PAP/XPP φ(ρz) correction, which is out of scope for relative-intensity templating but must be flagged. **Minimum viable EDS mode:** an `excitation='electron'` switch that (a) swaps the edge cut for an overvoltage cut, (b) swaps the shell-production term for Q_shell(E0), keeping transition_probability + fluorescence_yield + the CK cascade intact; plus the M-line and light-element energy rows; plus the energy-dependent resolution model (§2.1) and thin-window/dead-layer efficiency (§3.2), which matter most exactly in the sub-2 keV EDS band. Detector ε defaults must key off material (Si 3.64–3.66, Ge 2.96, CdTe 4.43 eV).

---

## 6. Prioritized roadmap (value-per-effort)

| # | Change | Benefit | Energy regime(s) | Effort |
|---|--------|---------|------------------|--------|
| 1 | **Drop double-counted ω** (`intensity = jump·emission_prob`) + invariant test | Fixes a real correctness bug distorting every cross-shell ratio 3–4× | all | **low** |
| 2 | **NNLS** non-negativity (`nnls::nnls(X, response)`) | Eliminates negative concentrations — the #1 XRF-LS failure | all | med |
| 3 | **Generic energy calibration** (`xrf_calibrate_energy`, GainFit/ZeroFit fallback) | Unblocks all non-Panalytical/SEM-EDS ingestion | all | **low** |
| 4 | **Light-element K-line energies** (Z=6–9 rows; yield/branching already present) | Enables C/N/O/F — core SEM-EDS use case | sem-eds, low-sub-keV | low–med |
| 5 | **Energy-dependent resolution** σ(E); populate `peaks$sigma` (pmap already per-row) | Correct template width sub-keV→100 keV; fixes areas | all | med |
| 6 | **Fix chi_sq** (Pearson, model denominator, guard 0) | Restores a usable goodness-of-fit metric | all | low–med |
| 7 | **Poisson/weighted LS** (thread counts+livetime; IRLS) | Correct SEs/LODs; efficient trace estimation | all | med |
| 8 | **Cross-section excitation weighting** — replace jump ratio with σ_shell(E0) from `x_ray_cross_sections` | Makes `beam_energy_kev` live; correct K:L vs energy | high-keV, handheld | med |
| 9 | **Coster-Kronig L-cascade** (wire cached f12/f13/f23) | Correct heavy-element L-family shape (Pb/Au/W/U) | handheld, high-keV | med |
| 10 | **Rayleigh + Compton scatter templates** (E_c shift, θ, joint fit) | Removes dominant high-kV false-positive source | handheld, high-keV | high |
| 11 | **Detector efficiency eff(E)** (window/dead-layer/active, photoelectric σ) | Physical inter-element ratios + quant at both extremes | all | high |
| 12 | **Escape peaks** (corrected f formula, same-coef columns, edge gate) | Kills 10–15% Ge / large CdTe false peaks | high-keV, sem-eds | high (med Si) |
| 13 | **M-line energies + radiative rates** (build from vendored EADL97) | Heavy elements below L edge — hard EDS blocker | sem-eds, low-sub-keV | high |
| 14 | **Energy-aware SNIP window** (√E transform / blockwise; expose decreasing/order/compton) | Correct baseline across the range | all | med |
| 15 | **Template/QR caching across batch** | Batch speed (minutes→seconds) | all | med |
| 16 | **Calibration (zero,gain) refinement** (varpro Gauss-Newton) | Robust single-cal wide-range/cross-instrument fits | high-keV, all | high |
| 17 | **Electron-excitation mode** (Bote-Salvat Q_shell, overvoltage cut) | Physically meaningful SEM-EDS relative intensities | sem-eds | high |
| 18 | **Quant layer** (Compton-norm tier 1; FP/Sherman tier 2, add MAC data) | Turns intensities into concentrations across matrices | all | high |
| 19 | Sparse/windowed template build (`findInterval` + dgCMatrix) | Scales to 8k–16k-channel SDD; memory | all | med |
| 20 | Hypermet tail/shelf lineshape | Correct low-E/CdTe areas; less neighbor leakage | low-sub-keV, high-keV | high |
| 21 | Sum/pile-up templates (two-pass, dead-time gated) | High-rate false-positive suppression | handheld, high-keV | high |
| 22 | Rank/condition-number diagnostics; NA-not-0 for aliased | Surfaces unresolvable overlaps instead of silent 0 | all | med |
| 23 | `discreteFilter.cpp` RMS/abs convergence metric | Fixes dormant early-stop bug before enabling | all | low |

**Suggested first sprint (all low/med, high value): #1–#7** — these fix outright bugs and unblock ingestion + resolution + statistics with no new physics data, and are prerequisites the later physics items (#8–#18) build on. `x_ray_cross_sections`, the Coster-Kronig table, and the EADL97 M-shell files are already in the package — items #8, #9, and #13 are largely activation, not acquisition.