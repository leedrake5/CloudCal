
#' Add smooth using iterative filtering
#'
#' @param filter The filter which should be applied
#' @param .iter Maximum number of iterations to smooth
#' @param .epsilon Further constrain maximum iterations
#' @param .values Which values to smooth
#' @inheritParams xrf_add_smooth
#'
#' @export
#'
xrf_add_smooth_filter <- function(.spectra, .values = .data$.spectra$cps,
                                  filter = xrf_filter_gaussian(),
                                  .iter = 5, .epsilon = -1, .env = parent.frame()) {
  .values <- enquo(.values)
  xrf_add_smooth(
    .spectra,
    smooth_wrap,
    !!.values,
    !!enquo(filter),
    iterations = !!enquo(.iter),
    epsilon = !!enquo(.epsilon),
    .env = .env
  )
}

#' Generate smoothing filters
#'
#' @param width The width of the smoothing window (an odd number)
#' @param alpha Higher alpha makes the smoothing window more focused on the center.
#'
#' @return A numeric vector of length \code{width}
#' @export
#'
#' @examples
#' plot(xrf_filter_gaussian())
#' points(xrf_filter_pyramid(), col = "red")
#'
#'
xrf_filter_pyramid <- function(width = 7) {
  stopifnot(is.numeric(width), length(width) == 1, is.finite(width), width >= 1)
  # Match xrf_filter_gaussian: the kernel needs an odd, integer number of taps. The old guard
  # `(width %% 2) != 0` was fooled by non-integers (e.g. 20.327 %% 2 = 0.327 != 0 passes, then
  # `%/% 2` silently floors to a wrong-length kernel). Coerce to the nearest odd integer and warn, so a
  # caller optimizing width over a continuous range cannot silently mis-size the filter. `width == 1` is a
  # legitimate identity (no smoothing); anything >= 2 coerces to the nearest odd >= 3 (a request to smooth
  # must not collapse to the identity -- e.g. width = 2 previously rounded to 1, a silent no-op).
  width_odd <- if (width < 2) 1 else max(3, 2 * round((width - 1) / 2) + 1)
  if (!isTRUE(width == width_odd)) {
    warning("xrf_filter_pyramid(): 'width' must be an odd integer >= 1; coercing ",
            width, " to ", width_odd, ".", call. = FALSE)
    width <- width_odd
  }
  if(width == 1) return(1)
  mid <- width %/% 2
  f <- c(
    seq(1, mid + 1),
    seq(mid, 1)
  )
  f / sum(f)
}

#' @rdname xrf_filter_pyramid
#' @export
xrf_filter_gaussian <- function(width = 7, alpha = 2.5) {
  stopifnot(
    is.numeric(width), length(width) == 1, is.finite(width),
    is.numeric(alpha), length(alpha) == 1, alpha > 0
  )
  # The kernel must have an odd, integer number of taps (a symmetric window around a centre point). The
  # old guard `(width %% 2) != 0` was fooled by non-integers -- e.g. width = 20.327 passes (0.327 != 0) but
  # then builds an even-length (invalid) kernel that fails downstream. Coerce to the nearest valid odd
  # integer (>= 3) and warn, so a caller optimizing width over a continuous range cannot silently break it.
  width_odd <- max(3, 2 * round((width - 1) / 2) + 1)
  if (!isTRUE(width == width_odd)) {
    warning("xrf_filter_gaussian(): 'width' must be an odd integer >= 3; coercing ",
            width, " to ", width_odd, ".", call. = FALSE)
    width <- width_odd
  }
  hw <- width %/% 2 # halfwidth
  e <- exp(1) # eulers number
  a <- alpha
  ret <- exp(
    -0.5 * (a * (seq(0, width - 1) - hw) / hw) ^ 2
  )
  ret / sum(ret)
}

# wraps iterative smoother with better type checking
smooth_wrap <- function(x, f, iterations = 1, epsilon = -1) {
  stopifnot(
    is.numeric(x), length(x) > length(f),
    is.numeric(f), (length(f) %% 2) != 0,
    length(iterations) == 1, iterations >= 1,
    is.numeric(epsilon), length(epsilon) == 1
  )
  discreteFilterIterative(x, f, iterations = iterations, epsilon = epsilon)
}

#' Smooth spectra using a function
#'
#' @inheritParams xrf_add_baseline
#'
#' @return A modified .spectra
#' @export
#'
xrf_add_smooth <- function(.spectra, .fun, ..., .env = parent.frame()) {

  dots <- quos(...)
  .spectra$.spectra <- purrr::map(purrr::transpose(.spectra), function(spectrum) {
    x <- spectrum$.spectra

    # args evaluated within each row
    args <- purrr::map(dots, rlang::eval_tidy, data = spectrum, env = .env)
    x$smooth <- do.call(.fun, args)
    x
  })

  .spectra
}

