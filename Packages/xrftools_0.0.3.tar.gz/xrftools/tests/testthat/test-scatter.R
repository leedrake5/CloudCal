context("scatter")

test_that("xrf_scatter_peaks builds Rayleigh + Compton templates with the correct Compton shift", {
  sp <- xrf_scatter_peaks(xrf_tube("Rh", kv = 40), xrf_geometry(scatter_angle_deg = 135),
                          detector_type = "SDD")
  expect_setequal(unique(sp$element), c("scatter_rayleigh", "scatter_compton"))
  expect_true(all(c("energy_kev", "sigma", "relative_peak_intensity") %in% colnames(sp)))

  # Rayleigh sits at the tube line energy; Compton is shifted down by the Compton formula
  ray <- sp[sp$element == "scatter_rayleigh", ]
  com <- sp[sp$element == "scatter_compton", ]
  E <- ray$energy_kev[1]
  theta <- 135 * pi / 180
  expect_equal(com$energy_kev[1], E / (1 + (E / 510.999) * (1 - cos(theta))))
  expect_lt(com$energy_kev[1], E)

  # Compton peak is broader than the detector (Rayleigh) width
  expect_gt(com$sigma[1], ray$sigma[1])

  # messy vendor anode strings ("Ag 50") are tolerated
  expect_silent(xrf_scatter_peaks(xrf_tube("Ag 50", kv = 30)))
  expect_error(xrf_scatter_peaks(xrf_tube("NotAnElement", kv = 30)), "not a recognized element")
})

test_that("scatter templates are added to the deconvolution when a tube is supplied", {
  e <- seq(2, 25, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  co <- 20.216 / (1 + (20.216 / 510.999) * (1 - cos(135 * pi / 180)))
  y <- xrftools:::gaussian_fun(e, 6.40, sig(6.40), 500) +          # Fe Ka
    xrftools:::gaussian_fun(e, 20.216, sig(20.216), 300) +        # Rh Ka Rayleigh
    xrftools:::gaussian_fun(e, co, 2 * sig(co), 200)              # Rh Ka Compton
  peaks <- xrf_energies(c("Fe", "Ti", "Ca"), beam_energy_kev = 40)

  d_no <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "SDD")
  d_sc <- xrf_deconvolute_gaussian_least_squares(
    e, y, peaks = peaks, detector_type = "SDD",
    tube = xrf_tube("Rh", kv = 40), geometry = xrf_geometry(scatter_angle_deg = 135))

  # scatter templates appear and absorb the tube-scatter bumps -> much better fit
  expect_true(all(c("scatter_rayleigh", "scatter_compton") %in% d_sc$peaks$element))
  expect_false(any(c("scatter_rayleigh", "scatter_compton") %in% d_no$peaks$element))
  expect_true(all(d_sc$peaks$height[grepl("scatter", d_sc$peaks$element)] > 0))
  expect_gt(d_sc$fit$r2, d_no$fit$r2)

  # scatter = FALSE forces them off even with a tube present
  d_off <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "SDD",
                                                  tube = xrf_tube("Rh", kv = 40), scatter = FALSE)
  expect_false(any(grepl("scatter", d_off$peaks$element)))
})
