context("scatter")

test_that("xrf_scatter_peaks builds Rayleigh + Compton templates with the correct Compton shift", {
  # gaussian mode: the legacy single-line-per-anode-line Compton semantics this test asserts
  sp <- xrf_scatter_peaks(xrf_tube("Rh", kv = 40), xrf_geometry(scatter_angle_deg = 135),
                          detector_type = "SDD", compton_shape = "gaussian")
  expect_setequal(unique(sp$element), c("scatter_rayleigh", "scatter_compton"))
  expect_true(all(c("energy_kev", "sigma", "relative_peak_intensity") %in% colnames(sp)))

  # Rayleigh sits at the tube line energy; Compton is shifted down by the Compton formula
  ray <- sp[sp$element == "scatter_rayleigh", ]
  com <- sp[sp$element == "scatter_compton", ]
  E <- ray$energy_kev[1]
  theta <- 135 * pi / 180
  expect_equal(com$energy_kev[1], E / (1 + (E / 510.999) * (1 - cos(theta))))
  expect_lt(com$energy_kev[1], E)

  # Compton peak is broader than the detector (Rayleigh) width
  expect_gt(com$sigma[1], ray$sigma[1])

  # messy vendor anode strings ("Ag 50") are tolerated
  expect_silent(xrf_scatter_peaks(xrf_tube("Ag 50", kv = 30)))
  expect_error(xrf_scatter_peaks(xrf_tube("NotAnElement", kv = 30)), "not a recognized element")
})

test_that("scatter templates are added to the deconvolution when a tube is supplied", {
  e <- seq(2, 25, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  co <- 20.216 / (1 + (20.216 / 510.999) * (1 - cos(135 * pi / 180)))
  y <- xrftools:::gaussian_fun(e, 6.40, sig(6.40), 500) +          # Fe Ka
    xrftools:::gaussian_fun(e, 20.216, sig(20.216), 300) +        # Rh Ka Rayleigh
    xrftools:::gaussian_fun(e, co, 2 * sig(co), 200)              # Rh Ka Compton
  peaks <- xrf_energies(c("Fe", "Ti", "Ca"), beam_energy_kev = 40)

  d_no <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "SDD")
  d_sc <- xrf_deconvolute_gaussian_least_squares(
    e, y, peaks = peaks, detector_type = "SDD",
    tube = xrf_tube("Rh", kv = 40), geometry = xrf_geometry(scatter_angle_deg = 135))

  # scatter templates appear and absorb the tube-scatter bumps -> much better fit
  expect_true(all(c("scatter_rayleigh", "scatter_compton") %in% d_sc$peaks$element))
  expect_false(any(c("scatter_rayleigh", "scatter_compton") %in% d_no$peaks$element))
  expect_true(all(d_sc$peaks$height[grepl("scatter", d_sc$peaks$element)] > 0))
  expect_gt(d_sc$fit$r2, d_no$fit$r2)

  # scatter = FALSE forces them off even with a tube present
  d_off <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "SDD",
                                                  tube = xrf_tube("Rh", kv = 40), scatter = FALSE)
  expect_false(any(grepl("scatter", d_off$peaks$element)))
})

test_that("xrf_infer_scatter_geometry recovers the angle and resists energy-gain miscalibration", {
  anode <- "Rh"; kv <- 45
  E0 <- 20.216; mec2 <- 510.999
  Ecomp <- function(theta) E0 / (1 + (E0 / mec2) * (1 - cos(theta * pi / 180)))
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  grid <- seq(1, 30, 0.02)
  # synthetic anode-scatter spectrum: Rayleigh at E0 (detector width) + a broadened Compton at the shifted
  # energy; `gain` scales the ENERGY axis to emulate an energy-calibration error.
  make_spec <- function(theta, gain = 1, a_ray = 1000, a_com = 1200) {
    Ec <- Ecomp(theta)
    counts <- xrftools:::gaussian_fun(grid, E0, sig(E0), a_ray) +
      xrftools:::gaussian_fun(grid, Ec, 2.5 * sig(Ec), a_com) + 40
    list(energy = grid * gain, counts = counts)
  }
  # recovers a range of true angles to within a couple degrees, and reports the injected Compton broadening
  for (theta in c(120, 135, 150)) {
    s <- make_spec(theta)
    g <- xrf_infer_scatter_geometry(s$energy, s$counts, anode = anode, tube_kv = kv)
    expect_true(g$confident)
    expect_lt(abs(g$scatter_angle_deg - theta), 3)
    expect_lt(abs(g$compton_broadening - 2.5), 0.6)
  }
  # a +/-1% energy-gain error must barely move the angle: the measured-Rayleigh anchor cancels a common gain
  # factor (with the old theoretical-E0 anchor a 1% gain swung theta by ~20 deg).
  ang <- function(gain) {
    s <- make_spec(135, gain)
    xrf_infer_scatter_geometry(s$energy, s$counts, anode, kv)$scatter_angle_deg
  }
  a0 <- ang(1)
  expect_lt(abs(ang(1.01) - a0), 4)
  expect_lt(abs(ang(0.99) - a0), 4)
})

test_that("xrf_infer_scatter_geometry falls back to the anode L-series below the K-edge (M4)", {
  # W K-edge is 69.5 keV; a 45 kV W tube excites only the W L-series (La1 ~ 8.40 keV), so the K path is
  # unavailable and the inference must anchor on the L line instead of dead-ending.
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  grid <- seq(1, 30, 0.02)
  E0 <- 8.40; k <- E0 / 510.999
  Ec <- E0 / (1 + k * (1 - cos(150 * pi / 180)))
  counts <- xrftools:::gaussian_fun(grid, E0, sig(E0), 1500) +
    xrftools:::gaussian_fun(grid, Ec, 2.5 * sig(Ec), 1800) + 40
  g <- xrf_infer_scatter_geometry(grid, counts, anode = "W", tube_kv = 45)
  expect_identical(g$anode_line, "L")             # used the L-series, not a K-not-excited dead end
  expect_equal(g$e_anode, E0, tolerance = 0.3)    # anchored on the W L-alpha line
  expect_false(grepl("no anode|no excited anode", g$reason))
  # a Rh tube at 45 kV is above the Rh K-edge, so it still takes the K-alpha path
  gk <- xrf_infer_scatter_geometry(grid, counts, anode = "Rh", tube_kv = 45)
  expect_identical(gk$anode_line, "K")
})

test_that("scatter templates use Ebel fluxes x scatter cross sections x the sample kernel (P4)", {
  # a realistic tube EXIT WINDOW (Be) suppresses the anode-L flux; without it the exact fixed-angle
  # form factor correctly makes the unfiltered Rayleigh template L-dominated at backscatter
  sp <- xrf_scatter_peaks(xrf_tube("Rh", kv = 40, filter = "Be 300"),
                          xrf_geometry(scatter_angle_deg = 135), detector_type = "SDD")
  ray <- sp[sp$element == "scatter_rayleigh", ]
  com <- sp[sp$element == "scatter_compton", ]
  # the thick-sample self-absorption kernel keeps the K components dominant (soft anode-L scatter
  # barely escapes the sample) even for an unfiltered tube
  expect_equal(ray$energy_kev[which.max(ray$relative_peak_intensity)], 20.216, tolerance = 0.05)
  expect_lt(sum(com$relative_peak_intensity[com$energy_kev < 5]),
            0.1 * sum(com$relative_peak_intensity[com$energy_kev > 15]))
  # scatterer choice reshapes the template (heavier scatterer absorbs soft scatter more)
  sp_fe <- xrf_scatter_peaks(xrf_tube("Rh", kv = 40, filter = "Be 300"),
                             xrf_geometry(scatter_angle_deg = 135),
                             detector_type = "SDD", scatterer = "Fe")
  expect_false(isTRUE(all.equal(sp$relative_peak_intensity,
                                sp_fe$relative_peak_intensity[match(paste(sp$element, sp$trans),
                                  paste(sp_fe$element, sp_fe$trans))])))
  # in the deconvolution, escape = TRUE now gives scatter parents their (tied) escape satellites
  e <- seq(2, 25, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  co <- 20.216 / (1 + (20.216 / 510.999) * (1 - cos(135 * pi / 180)))
  y <- xrftools:::gaussian_fun(e, 6.40, sig(6.40), 500) +
    xrftools:::gaussian_fun(e, 20.216, sig(20.216), 300) +
    xrftools:::gaussian_fun(e, co, 2 * sig(co), 200)
  d <- xrf_deconvolute_gaussian_least_squares(
    e, y, peaks = xrf_energies(c("Fe"), 40), detector_type = "SDD", escape = TRUE,
    tube = xrf_tube("Rh", kv = 40), geometry = xrf_geometry(scatter_angle_deg = 135))
  expect_true(all(c("scatter_rayleigh", "scatter_compton") %in% d$peaks$element))
})

test_that("Compton features carry the impulse-approximation Doppler shape (Biggs profiles)", {
  # data integrity: 2 * integral of J over the one-sided grid ~ Z
  cp <- xrftools::x_ray_compton_profiles
  for (el in c("Si", "Fe")) {
    g <- cp[cp$element == el, ]
    z <- match(el, xrftools:::all_elements)
    n_el <- 2 * sum(diff(g$pz_au) * (head(g$j_total, -1) + tail(g$j_total, -1)) / 2)
    expect_equal(n_el, z, tolerance = 0.08 * z)
  }

  # cluster physics for Rh Ka at 135 deg on Si
  E0 <- 20.216; th <- 135 * pi / 180
  E_C <- E0 / (1 + (E0 / 510.999) * (1 - cos(th)))
  # fine node grid for the split/centroid metrics: at the packaged 31 nodes, whether the peak node
  # lands a few tens of eV above or below E_C swings the coarse side-split by ~0.15 (grid phase),
  # so distributional claims are asserted on a dense grid
  cl <- xrftools:::.xrf_compton_doppler_cluster(E0, th, "Si", n_nodes = 301L)
  expect_equal(sum(cl$weight), 1, tolerance = 1e-12)
  mu <- sum(cl$energy_kev * cl$weight)
  expect_lt(abs(mu - E_C), 0.35)                       # centred near the Compton line (small defect ok)
  fwhm <- 2.3548 * sqrt(sum(cl$weight * (cl$energy_kev - mu)^2))
  expect_gt(fwhm, 0.3); expect_lt(fwhm, 2.0)           # real Doppler width, keV scale
  expect_gt(sum(cl$weight[cl$energy_kev < E_C]),       # asymmetry: heavier LOW-energy side
            sum(cl$weight[cl$energy_kev > E_C]))
  expect_lt(max(cl$energy_kev), E0)                    # kinematic cutoff below the incident line

  # profile templates preserve each line's total Compton intensity (same KN * S * kernel weight)
  tb <- xrf_tube("Rh", kv = 40, filter = "Be 300")
  gm <- xrf_geometry(scatter_angle_deg = 135)
  sp_p <- xrf_scatter_peaks(tb, gm, detector_type = "SDD", compton_shape = "profile")
  sp_g <- xrf_scatter_peaks(tb, gm, detector_type = "SDD", compton_shape = "gaussian")
  tot <- function(sp) sum(sp$relative_peak_intensity[sp$element == "scatter_compton"])
  expect_equal(tot(sp_p), tot(sp_g), tolerance = 1e-9)
  expect_gt(sum(sp_p$element == "scatter_compton"), sum(sp_g$element == "scatter_compton"))

  # and the deconvolution fits its own profile-shaped templates cleanly
  e <- seq(2, 25, 0.02); sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  y <- numeric(length(e))
  for (i in seq_len(nrow(sp_p))) {
    y <- y + sp_p$relative_peak_intensity[i] / sp_p$sigma[i] * 1e-11 *
      exp(-0.5 * ((e - sp_p$energy_kev[i]) / sp_p$sigma[i])^2)
  }
  d <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = xrf_energies("Fe", 40),
                                              detector_type = "SDD", tube = tb, geometry = gm)
  expect_gt(d$fit$r2, 0.999)
  expect_true(all(d$peaks$height[grepl("^scatter_", d$peaks$element)] >= 0))
})

test_that("per-shell profiles apply binding thresholds (Compton defect)", {
  sh <- xrftools::x_ray_compton_profiles_shells
  si <- sh[sh$element == "Si", ]
  expect_equal(sum(unique(si[, c("shell", "occupancy")])$occupancy), 14)
  expect_equal(max(si$binding_kev), 1.839, tolerance = 1e-3)           # Si K
  # the repaired Eu point is back on its shell's declining curve
  eu <- sh[sh$element == "Eu" & sh$shell == 3 & sh$pz_au == 30, ]
  expect_lt(eu$j_shell, 0.02)
  # bound vs unbound cluster (Rh Ka @ 135 on Si): binding trims the HIGH-E2 side (small transfers
  # cannot eject core electrons) and shifts the centroid down -- the Compton defect
  E0 <- 20.216; th <- 135 * pi / 180
  E_C <- E0 / (1 + (E0 / 510.999) * (1 - cos(th)))
  cb <- xrftools:::.xrf_compton_doppler_cluster(E0, th, "Si", n_nodes = 301L, bound = TRUE)
  cu <- xrftools:::.xrf_compton_doppler_cluster(E0, th, "Si", n_nodes = 301L, bound = FALSE)
  lo_m <- function(cl) sum(cl$weight[cl$energy_kev < E_C])
  expect_gt(lo_m(cb), lo_m(cu))                        # binding displaces mass to the LOW side
  expect_lt(sum(cb$energy_kev * cb$weight), sum(cu$energy_kev * cu$weight))   # Compton defect
  expect_lt(max(cb$energy_kev), max(cu$energy_kev))    # small-transfer truncation is real
  # a soft anode-L line (tiny transfer: only valence shells open) still yields a valid cluster
  cl3 <- xrftools:::.xrf_compton_doppler_cluster(2.697, th, "Si")
  expect_equal(sum(cl3$weight), 1, tolerance = 1e-12)
})

test_that("in-detector Compton shelf: KN recoil spectrum and tied templates", {
  # recoil spectrum: positive on [0, Tmax], zero outside, rising toward the Compton edge
  E <- 25; Tm <- E * 2 * (E / 510.999) / (1 + 2 * E / 510.999)
  Ts <- seq(0.05, Tm * 0.999, length.out = 50)
  N <- xrftools:::.xrf_kn_electron_spectrum(E, Ts)
  expect_true(all(N > 0))
  expect_gt(N[45], N[25])                                              # rises toward the edge
  expect_equal(xrftools:::.xrf_kn_electron_spectrum(E, Tm * 1.05), 0)
  # shelf templates: tied element, correct total fraction, high-E parents only
  pk <- tibble::tibble(element = c("scatter_rayleigh", "Fe"), energy_kev = c(25, 6.4),
                       relative_peak_intensity = c(1, 1))
  sh <- xrf_detector_compton_shelf(pk, detector_type = "SDD")
  expect_true(all(sh$element == "scatter_rayleigh"))                   # Fe (Tmax 0.16 keV) skipped
  f_exp <- (xrftools:::.xrf_material_scatter_mu("Si", 25, "compton") /
              xrf_mass_attenuation("Si", 25, type = "photoelectric")) *
    exp(-xrf_mass_attenuation("Si", 25, type = "total") * 2.33 * 0.045 / 2)
  expect_equal(sum(sh$relative_peak_intensity), f_exp, tolerance = 1e-6)
  expect_gt(f_exp, 0.05)                               # ~6% of the photopeak at 25 keV on 450 um Si...
  f45 <- (xrftools:::.xrf_material_scatter_mu("Si", 45, "compton") /
            xrf_mass_attenuation("Si", 45, type = "photoelectric")) *
    exp(-xrf_mass_attenuation("Si", 45, type = "total") * 2.33 * 0.045 / 2)
  expect_gt(f45, 0.3)                                  # ...and ~46% at 45 keV (upper half of a 50 kV beam)
  expect_true(all(sh$energy_kev < Tm & sh$energy_kev >= 0.25))
  # deconvolution integration: the shelf puts tied response under the light elements
  e <- seq(0.5, 26, 0.02)
  y <- xrftools:::gaussian_fun(e, 25, xrf_detector_sigma_kev(25, "SDD"), 300) +
    2 * (e < 2.3) * (e > 0.3)
  pk2 <- tibble::tibble(element = "Hg", energy_kev = 25, relative_peak_intensity = 1)  # stand-in line
  d_on <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = pk2, detector_type = "SDD",
                                                 detector_compton = TRUE)
  d_off <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = pk2, detector_type = "SDD")
  comp_at <- function(d, ee) sum(unname(d$components$response_fit[d$components$element == "Hg" &
                                                                    abs(d$components$energy_kev - ee) < 0.011]))
  expect_gt(comp_at(d_on, 1.5), 0)                                     # tied shelf under 2 keV
  expect_equal(comp_at(d_off, 1.5), 0)
  expect_gt(d_on$fit$r2, d_off$fit$r2)                                 # and it explains the pedestal
})
