context("scatter")

test_that("xrf_scatter_peaks builds Rayleigh + Compton templates with the correct Compton shift", {
  sp <- xrf_scatter_peaks(xrf_tube("Rh", kv = 40), xrf_geometry(scatter_angle_deg = 135),
                          detector_type = "SDD")
  expect_setequal(unique(sp$element), c("scatter_rayleigh", "scatter_compton"))
  expect_true(all(c("energy_kev", "sigma", "relative_peak_intensity") %in% colnames(sp)))

  # Rayleigh sits at the tube line energy; Compton is shifted down by the Compton formula
  ray <- sp[sp$element == "scatter_rayleigh", ]
  com <- sp[sp$element == "scatter_compton", ]
  E <- ray$energy_kev[1]
  theta <- 135 * pi / 180
  expect_equal(com$energy_kev[1], E / (1 + (E / 510.999) * (1 - cos(theta))))
  expect_lt(com$energy_kev[1], E)

  # Compton peak is broader than the detector (Rayleigh) width
  expect_gt(com$sigma[1], ray$sigma[1])

  # messy vendor anode strings ("Ag 50") are tolerated
  expect_silent(xrf_scatter_peaks(xrf_tube("Ag 50", kv = 30)))
  expect_error(xrf_scatter_peaks(xrf_tube("NotAnElement", kv = 30)), "not a recognized element")
})

test_that("scatter templates are added to the deconvolution when a tube is supplied", {
  e <- seq(2, 25, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  co <- 20.216 / (1 + (20.216 / 510.999) * (1 - cos(135 * pi / 180)))
  y <- xrftools:::gaussian_fun(e, 6.40, sig(6.40), 500) +          # Fe Ka
    xrftools:::gaussian_fun(e, 20.216, sig(20.216), 300) +        # Rh Ka Rayleigh
    xrftools:::gaussian_fun(e, co, 2 * sig(co), 200)              # Rh Ka Compton
  peaks <- xrf_energies(c("Fe", "Ti", "Ca"), beam_energy_kev = 40)

  d_no <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "SDD")
  d_sc <- xrf_deconvolute_gaussian_least_squares(
    e, y, peaks = peaks, detector_type = "SDD",
    tube = xrf_tube("Rh", kv = 40), geometry = xrf_geometry(scatter_angle_deg = 135))

  # scatter templates appear and absorb the tube-scatter bumps -> much better fit
  expect_true(all(c("scatter_rayleigh", "scatter_compton") %in% d_sc$peaks$element))
  expect_false(any(c("scatter_rayleigh", "scatter_compton") %in% d_no$peaks$element))
  expect_true(all(d_sc$peaks$height[grepl("scatter", d_sc$peaks$element)] > 0))
  expect_gt(d_sc$fit$r2, d_no$fit$r2)

  # scatter = FALSE forces them off even with a tube present
  d_off <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "SDD",
                                                  tube = xrf_tube("Rh", kv = 40), scatter = FALSE)
  expect_false(any(grepl("scatter", d_off$peaks$element)))
})

test_that("xrf_infer_scatter_geometry recovers the angle and resists energy-gain miscalibration", {
  anode <- "Rh"; kv <- 45
  E0 <- 20.216; mec2 <- 510.999
  Ecomp <- function(theta) E0 / (1 + (E0 / mec2) * (1 - cos(theta * pi / 180)))
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  grid <- seq(1, 30, 0.02)
  # synthetic anode-scatter spectrum: Rayleigh at E0 (detector width) + a broadened Compton at the shifted
  # energy; `gain` scales the ENERGY axis to emulate an energy-calibration error.
  make_spec <- function(theta, gain = 1, a_ray = 1000, a_com = 1200) {
    Ec <- Ecomp(theta)
    counts <- xrftools:::gaussian_fun(grid, E0, sig(E0), a_ray) +
      xrftools:::gaussian_fun(grid, Ec, 2.5 * sig(Ec), a_com) + 40
    list(energy = grid * gain, counts = counts)
  }
  # recovers a range of true angles to within a couple degrees, and reports the injected Compton broadening
  for (theta in c(120, 135, 150)) {
    s <- make_spec(theta)
    g <- xrf_infer_scatter_geometry(s$energy, s$counts, anode = anode, tube_kv = kv)
    expect_true(g$confident)
    expect_lt(abs(g$scatter_angle_deg - theta), 3)
    expect_lt(abs(g$compton_broadening - 2.5), 0.6)
  }
  # a +/-1% energy-gain error must barely move the angle: the measured-Rayleigh anchor cancels a common gain
  # factor (with the old theoretical-E0 anchor a 1% gain swung theta by ~20 deg).
  ang <- function(gain) {
    s <- make_spec(135, gain)
    xrf_infer_scatter_geometry(s$energy, s$counts, anode, kv)$scatter_angle_deg
  }
  a0 <- ang(1)
  expect_lt(abs(ang(1.01) - a0), 4)
  expect_lt(abs(ang(0.99) - a0), 4)
})

test_that("xrf_infer_scatter_geometry falls back to the anode L-series below the K-edge (M4)", {
  # W K-edge is 69.5 keV; a 45 kV W tube excites only the W L-series (La1 ~ 8.40 keV), so the K path is
  # unavailable and the inference must anchor on the L line instead of dead-ending.
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  grid <- seq(1, 30, 0.02)
  E0 <- 8.40; k <- E0 / 510.999
  Ec <- E0 / (1 + k * (1 - cos(150 * pi / 180)))
  counts <- xrftools:::gaussian_fun(grid, E0, sig(E0), 1500) +
    xrftools:::gaussian_fun(grid, Ec, 2.5 * sig(Ec), 1800) + 40
  g <- xrf_infer_scatter_geometry(grid, counts, anode = "W", tube_kv = 45)
  expect_identical(g$anode_line, "L")             # used the L-series, not a K-not-excited dead end
  expect_equal(g$e_anode, E0, tolerance = 0.3)    # anchored on the W L-alpha line
  expect_false(grepl("no anode|no excited anode", g$reason))
  # a Rh tube at 45 kV is above the Rh K-edge, so it still takes the K-alpha path
  gk <- xrf_infer_scatter_geometry(grid, counts, anode = "Rh", tube_kv = 45)
  expect_identical(gk$anode_line, "K")
})
