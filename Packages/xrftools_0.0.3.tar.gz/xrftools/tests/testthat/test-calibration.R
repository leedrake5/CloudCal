context("calibration")

test_that("channel-to-energy calibration is linear (+ optional quadratic)", {
  expect_equal(xrf_calibrate_energy(0:3, gain = 0.02, zero = 0.01), c(0.01, 0.03, 0.05, 0.07))
  # quadratic term
  expect_equal(
    xrf_calibrate_energy(10, gain = 0.02, zero = 0, quad = 1e-4),
    0.02 * 10 + 1e-4 * 100
  )
  expect_error(xrf_calibrate_energy(0:3, gain = c(0.02, 0.03)), "length\\(gain\\) == 1")
})

test_that("xrf_spectra_from_counts builds a valid spectra with counts + livetime", {
  cts <- rpois(256, 5)
  sp <- xrf_spectra_from_counts(cts, gain = 0.02, zero = 0, livetime = 60, SampleIdent = "demo")

  expect_s3_class(sp, "spectra")
  expect_silent(validate_spectra(sp))

  s <- sp$.spectra[[1]]
  expect_setequal(colnames(s), c("channel", "energy_kev", "counts", "cps"))
  expect_equal(s$cps, cts / 60)
  expect_equal(sp$LiveTime, 60)

  # 0-based channels by default -> first energy is `zero`
  expect_equal(s$energy_kev[1], 0)

  # without livetime, cps falls back to raw counts
  sp2 <- xrf_spectra_from_counts(cts, gain = 0.02)
  expect_equal(sp2$.spectra[[1]]$cps, as.numeric(cts))
})
