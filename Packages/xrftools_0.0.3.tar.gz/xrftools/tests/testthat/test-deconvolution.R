context("test-deconvolution.R")

test_that("test deconvolution", {

  test_df <- tibble::tibble(
    energy_kev = seq(1, 30, 0.1),
    response = xrftools:::gaussian_fun(energy_kev, mu = 5, sigma = 1, height = 4) +
      xrftools:::gaussian_fun(energy_kev, mu = 10, sigma = 2, height = 2) +
      xrftools:::gaussian_fun(energy_kev, mu = 15, sigma = 0.5, height = 1) +
      rnorm(length(energy_kev), mean = 0, sd = 0.05)
  )

  deconv <- xrf_deconvolute_gaussian_least_squares(
    test_df$energy_kev, test_df$response,
    peaks = tibble::tibble(
      element = c("a", "b", "b"),
      energy_kev = c(5, 10, 15),
      sigma = c(1, 2, 0.5),
      relative_peak_intensity = c(sigma * c(4, 2, 1))
    )
  )

  # make sure peaks line up and are the right height
  expect_equal(deconv$peaks$element, c("a", "b"))
  expect_true(all(abs(deconv$peaks$height - c(4, 2)) < 0.05))

  plot(test_df, type = "l", col = "blue")
  lines(deconv$response$energy_kev, deconv$response$response_fit)
  lines(
    deconv$components$energy_kev[deconv$components$element == "a"],
    deconv$components$response_fit[deconv$components$element == "a"],
    col = "purple"
  )
  lines(
    deconv$components$energy_kev[deconv$components$element == "b"],
    deconv$components$response_fit[deconv$components$element == "b"],
    col = "red"
  )
})

test_that("test base deconvolution function", {

  spec <- read_xrf_example(.which = 7) %>%
    xrf_add_baseline_snip(.values = .spectra$cps, iterations = 20) %>%
    xrf_add_smooth_filter(filter = xrf_filter_gaussian(width = 7, alpha = 2.5), .iter = 5)

  spec_simple <- spec %>%
    dplyr::pull(.spectra) %>%
    dplyr::first() %>%
    dplyr::filter(energy_kev <= 7.5)

  deconv <- xrf_deconvolute_gaussian_least_squares(
    spec_simple$energy_kev,
    spec_simple$smooth - spec_simple$baseline,
    peaks = xrf_energies("lake_sediment")
  )

  # types of output
  expect_is(deconv, "deconvolution_fit")
  expect_setequal(names(deconv), c("fit", "response", "components", "peaks"))
  expect_is(deconv$fit, "data.frame")
  expect_is(deconv$response, "data.frame")
  expect_is(deconv$components, "data.frame")
  expect_is(deconv$peaks, "data.frame")

  # rows of output
  expect_equal(nrow(deconv$peaks), dplyr::n_distinct(xrf_energies("lake_sediment")$element))
  expect_equal(nrow(deconv$fit), 1)
  expect_equal(nrow(deconv$response), nrow(spec_simple))
  expect_equal(nrow(deconv$components), nrow(spec_simple) * nrow(deconv$peaks))
})

test_that("deconvolution works on spectra objects", {
  spec <- read_xrf_example(.which = 7) %>%
    dplyr::select(SampleIdent, ConditionSet, kV) %>%
    xrf_add_baseline_snip(.values = .spectra$cps, iterations = 20) %>%
    xrf_add_smooth_filter(filter = xrf_filter_gaussian(width = 7, alpha = 2.5), .iter = 5)

  spec_simple <- spec %>%
    dplyr::pull(.spectra) %>%
    dplyr::first()

  deconv <- xrf_deconvolute_gaussian_least_squares(
    spec_simple$energy_kev,
    spec_simple$cps - spec_simple$baseline,
    peaks = xrf_energies("lake_sediment"),
    energy_max_kev = 7.5
  )

  spec_deconv <- spec %>%
    xrf_add_deconvolution_gls(energy_max_kev = 7.5, peaks = xrf_energies("lake_sediment"))

  expect_identical(spec_deconv$.deconvolution_components[[1]], deconv$components)
})

test_that("nonneg (NNLS) clamps absent elements to zero instead of going negative", {
  e <- seq(1, 20, 0.05)
  # noise-free two-peak spectrum so the clamp is deterministic; "ghost" has no signal at 14 keV
  y <- xrftools:::gaussian_fun(e, 5, 0.1, 4000) + xrftools:::gaussian_fun(e, 10, 0.1, 2000)
  peaks <- tibble::tibble(
    element = c("a", "b", "ghost"),
    energy_kev = c(5, 10, 14),
    relative_peak_intensity = 1
  )

  d_nn <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, default_sigma = 0.1,
                                                 nonneg = TRUE)
  gh <- d_nn$peaks$element == "ghost"
  expect_true(all(d_nn$peaks$height >= 0))
  expect_equivalent(d_nn$peaks$height[gh], 0)             # clamped to exactly zero
  expect_true(is.na(d_nn$peaks$height_se[gh]))            # clamped -> NA (not a confident) SE
  # real peaks are still recovered
  expect_true(all(abs(d_nn$peaks$height[!gh] - c(4000, 2000)) < 1))

  # and with negatively-pushing noise, unconstrained LS would go negative but NNLS stays >= 0
  set.seed(42)
  y2 <- y + rnorm(length(e), 0, 5)
  d_free <- xrf_deconvolute_gaussian_least_squares(e, y2, peaks = peaks, default_sigma = 0.1,
                                                   nonneg = FALSE)
  d_nn2 <- xrf_deconvolute_gaussian_least_squares(e, y2, peaks = peaks, default_sigma = 0.1,
                                                  nonneg = TRUE)
  expect_true(all(d_nn2$peaks$height >= 0))
  expect_true(min(d_free$peaks$height) <= min(d_nn2$peaks$height))
})

test_that("Poisson weighting runs and chi_sq is finite even with zero-count channels", {
  set.seed(7)
  e <- seq(1, 20, 0.05)
  lt <- 15
  truth <- xrftools:::gaussian_fun(e, 5, 0.12, 300) + xrftools:::gaussian_fun(e, 12, 0.12, 120)
  counts <- rpois(length(e), truth * lt)   # many channels are exactly zero
  cps <- counts / lt
  peaks <- tibble::tibble(element = c("a", "b"), energy_kev = c(5, 12), relative_peak_intensity = 1)

  # historic chi_sq = sum(resid^2 / response) would be NaN/Inf here (division by zero-count cps)
  d <- xrf_deconvolute_gaussian_least_squares(e, cps, peaks = peaks, default_sigma = 0.12,
                                              weighting = "poisson", counts = counts, livetime = lt)
  expect_identical(d$fit$weighting, "poisson")
  expect_true(is.finite(d$fit$chi_sq))
  expect_true(all(d$peaks$height >= 0))
  expect_true(all(is.finite(d$peaks$height_se)))

  # asking for poisson without counts warns and falls back
  expect_warning(
    xrf_deconvolute_gaussian_least_squares(e, cps, peaks = peaks, weighting = "poisson"),
    "requires"
  )
})

test_that("detector model gives energy-dependent peak widths", {
  peaks <- tibble::tibble(element = c("lo", "hi"), energy_kev = c(2, 40),
                          relative_peak_intensity = 1)
  e <- seq(0.5, 45, 0.05)
  y <- rep(0, length(e))
  d <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "SDD")
  # the 40 keV line must be assigned a wider sigma than the 2 keV line
  s_lo <- d$peaks$primary_sigma[d$peaks$element == "lo"]
  s_hi <- d$peaks$primary_sigma[d$peaks$element == "hi"]
  expect_gt(s_hi, s_lo)
  expect_equal(s_lo, xrf_detector_sigma_kev(2, "SDD"))
  expect_equal(s_hi, xrf_detector_sigma_kev(40, "SDD"))
})

test_that("deconvolution function errors are caught", {
  spec <- read_xrf_example(.which = 7)
  expect_error(xrf_add_deconvolution_fun(spec, function(...) "not a list obj"), "not a list")
  expect_error(xrf_add_deconvolution_fun(spec, function(...) list(1)), "empty or missing names")
  expect_error(xrf_add_deconvolution_fun(spec, function(...) list(1, a = "fish")), "empty or missing names")
  expect_silent(xrf_add_deconvolution_fun(spec, function(...) list(a = 1, b = 2)))
})

test_that("active_thickness_um is threaded through the xrf_add_deconvolution_gls WRAPPER", {
  # CloudCal drives the tidy wrapper (not the worker directly), so a dropped `!!active_thickness_um`
  # splice in xrf_add_deconvolution_gls would pass every worker-level test yet silently break production.
  # A wide grid spanning Ba L (~4.5) and K (~32 keV) lets the active-layer thickness reshape the fit.
  e <- seq(2, 40, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  y <- xrftools:::gaussian_fun(e, 4.47, sig(4.47), 500) +
    xrftools:::gaussian_fun(e, 32.19, sig(32.19), 500)
  spec <- tibble::tibble(spectrum_id = "s1",
                         .spectra = list(data.frame(energy_kev = e, smooth = y, baseline = 0)))
  wrap_h <- function(t) {
    o <- spec %>% xrf_add_deconvolution_gls(.spectra$energy_kev, .spectra$smooth - .spectra$baseline,
           peaks = xrf_energies("Ba", 60), detector_type = "SDD", efficiency = TRUE,
           active_thickness_um = t, cache_templates = FALSE)
    p <- o$.deconvolution_peaks[[1]]
    p$height[p$element == "Ba"]
  }
  h_thin <- wrap_h(50); h_thick <- wrap_h(3000)
  expect_gt(h_thin, 0)
  expect_gt(h_thick, 0)
  expect_gt(abs(h_thin - h_thick), 0.1 * h_thick)   # the wrapper genuinely forwards the argument
  expect_equal(wrap_h(NULL), wrap_h(450))           # NULL -> SDD preset, which is now the 450 um SDD
})
