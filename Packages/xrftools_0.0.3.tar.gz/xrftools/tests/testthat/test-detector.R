context("detector")

test_that("detector resolution grows with energy and follows the Fano+noise model", {
  # FWHM must increase monotonically with energy
  fw <- xrf_detector_fwhm_ev(c(0.28, 1.74, 5.9, 17.5, 59.3, 98.4), "SDD")
  expect_true(all(diff(fw) > 0))

  # explicit reconstruction of the model for a Si SDD preset
  p <- xrf_detector_presets()
  sdd <- p[p$type == "SDD", ]
  E_ev <- 5900
  expect_equal(
    xrf_detector_fwhm_ev(5.9, "SDD"),
    sqrt(sdd$noise_fwhm_ev^2 + (2.3548^2) * sdd$fano * sdd$epsilon_ev * E_ev)
  )

  # sigma is FWHM / 2.3548, converted to keV
  expect_equal(
    xrf_detector_sigma_kev(5.9, "SDD"),
    xrf_detector_fwhm_ev(5.9, "SDD") / 2.3548 / 1000
  )

  # a wider-gap / noisier material (CdTe) is broader than Si at the same energy
  expect_gt(xrf_detector_fwhm_ev(20, "CdTe"), xrf_detector_fwhm_ev(20, "SDD"))
})

test_that("explicit detector scalars override the preset", {
  base <- xrf_detector_fwhm_ev(6, "SDD")
  noisier <- xrf_detector_fwhm_ev(6, "SDD", noise_fwhm_ev = 120)
  expect_gt(noisier, base)

  # detector_type = NULL with scalars falls back to an Si (SDD) base
  expect_equal(
    xrf_detector_fwhm_ev(6, fano = 0.115, epsilon_ev = 3.64, noise_fwhm_ev = 50),
    xrf_detector_fwhm_ev(6, "SDD")
  )

  expect_error(xrf_detector_fwhm_ev(6, "NoSuchDetector"), "Unknown detector_type")
})

test_that("tube and geometry constructors carry their fields", {
  tb <- xrf_tube("Rh", kv = 40, ma = 0.1)
  expect_s3_class(tb, "xrf_tube")
  expect_identical(tb$anode, "Rh")
  expect_identical(tb$kv, 40)

  g <- xrf_geometry(incidence_deg = 45, takeoff_deg = 40, scatter_angle_deg = 135)
  expect_s3_class(g, "xrf_geometry")
  expect_identical(g$scatter_angle_deg, 135)
})
