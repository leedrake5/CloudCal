context("detector")

test_that("detector resolution grows with energy and follows the Fano+noise model", {
  # FWHM must increase monotonically with energy
  fw <- xrf_detector_fwhm_ev(c(0.28, 1.74, 5.9, 17.5, 59.3, 98.4), "SDD")
  expect_true(all(diff(fw) > 0))

  # explicit reconstruction of the model for a Si SDD preset
  p <- xrf_detector_presets()
  sdd <- p[p$type == "SDD", ]
  E_ev <- 5900
  expect_equal(
    xrf_detector_fwhm_ev(5.9, "SDD"),
    sqrt(sdd$noise_fwhm_ev^2 + (2.3548^2) * sdd$fano * sdd$epsilon_ev * E_ev)
  )

  # sigma is FWHM / 2.3548, converted to keV
  expect_equal(
    xrf_detector_sigma_kev(5.9, "SDD"),
    xrf_detector_fwhm_ev(5.9, "SDD") / 2.3548 / 1000
  )

  # a wider-gap / noisier material (CdTe) is broader than Si at the same energy
  expect_gt(xrf_detector_fwhm_ev(20, "CdTe"), xrf_detector_fwhm_ev(20, "SDD"))
})

test_that("explicit detector scalars override the preset", {
  base <- xrf_detector_fwhm_ev(6, "SDD")
  noisier <- xrf_detector_fwhm_ev(6, "SDD", noise_fwhm_ev = 120)
  expect_gt(noisier, base)

  # detector_type = NULL with scalars falls back to an Si (SDD) base
  expect_equal(
    xrf_detector_fwhm_ev(6, fano = 0.115, epsilon_ev = 3.64, noise_fwhm_ev = 50),
    xrf_detector_fwhm_ev(6, "SDD")
  )

  expect_error(xrf_detector_fwhm_ev(6, "NoSuchDetector"), "Unknown detector_type")
})

test_that("tube and geometry constructors carry their fields", {
  tb <- xrf_tube("Rh", kv = 40, ma = 0.1)
  expect_s3_class(tb, "xrf_tube")
  expect_identical(tb$anode, "Rh")
  expect_identical(tb$kv, 40)

  g <- xrf_geometry(incidence_deg = 45, takeoff_deg = 40, scatter_angle_deg = 135)
  expect_s3_class(g, "xrf_geometry")
  expect_identical(g$scatter_angle_deg, 135)
})

test_that("beam-filter transmission supports a stacked tri-filter and stays backward-compatible", {
  E <- c(5, 10, 20, 30)
  t1 <- xrftools:::.xrf_filter_transmission("Cu 100", E)   # single filter (legacy form)
  t2 <- xrftools:::.xrf_filter_transmission("Ti 25", E)
  t3 <- xrftools:::.xrf_filter_transmission("Al 300", E)
  # a handheld's "Cu 100; Ti 25; Al 300" stack transmits the product of the individual filters
  st <- xrftools:::.xrf_filter_transmission("Cu 100; Ti 25; Al 300", E)
  expect_equal(st, t1 * t2 * t3)
  expect_true(all(st <= t1))                     # adding filters can only remove flux
  expect_true(all(st >= 0 & st <= 1))
  # absent / unparseable -> no attenuation; comma is an accepted separator too
  expect_equal(xrftools:::.xrf_filter_transmission(NA, E), rep(1, length(E)))
  expect_equal(xrftools:::.xrf_filter_transmission("Cu 100, Ti 25, Al 300", E), st)
})
