context("efficiency")

test_that("photoelectric mass attenuation matches known values and handles compounds", {
  # Si photoelectric mu/rho (cm^2/g) vs NIST: ~244 @5, ~33 @10, ~4.4 @20 keV
  expect_equal(xrf_mass_attenuation("Si", 10), 33.4, tolerance = 0.05)
  expect_true(xrf_mass_attenuation("Si", 5) > xrf_mass_attenuation("Si", 20))   # falls with energy

  # CdTe is a mass-weighted mixture of Cd and Te
  mu_cd <- xrftools:::.xrf_element_pe_mu("Cd", 60)
  mu_te <- xrftools:::.xrf_element_pe_mu("Te", 60)
  expect_equal(xrf_mass_attenuation("CdTe", 60), 0.4684 * mu_cd + 0.5316 * mu_te, tolerance = 1e-6)

  expect_error(xrf_mass_attenuation("Xx", 10), "Unknown material")
})

test_that("detector efficiency: thin Si is transparent at high energy, CdTe is not", {
  # 450 um Si (modern SDD): ~full at 6 keV, small at 60 keV, tiny at 100 keV
  eff_si <- xrf_detector_efficiency(c(6, 60, 100), "SDD")
  expect_gt(eff_si[1], 0.9)
  expect_lt(eff_si[2], 0.05)
  expect_true(all(diff(eff_si) < 0))

  # CdTe stays efficient where Si has gone transparent
  expect_gt(xrf_detector_efficiency(60, "CdTe"), 0.8)
  expect_gt(xrf_detector_efficiency(60, "CdTe"), xrf_detector_efficiency(60, "SDD"))

  # efficiency is in [0, 1]
  eff <- xrf_detector_efficiency(c(0.3, 0.525, 1), "SDD")
  expect_true(all(eff >= 0 & eff <= 1))
  # a standard 8 um Be window blocks O Ka (0.525 keV) -- this is why light-element EDS needs an
  # ultra-thin / windowless detector; a 0.4 um window passes it
  expect_lt(xrf_detector_efficiency(0.525, "SDD", be_window_um = 8), 0.05)
  expect_gt(xrf_detector_efficiency(0.525, "SDD", be_window_um = 0.4), 0.4)

  # a thicker window cuts more low-energy signal
  expect_lt(xrf_detector_efficiency(2, "SDD", be_window_um = 250),
            xrf_detector_efficiency(2, "SDD", be_window_um = 8))
})

test_that("escape peaks respect the detector K edge and give sensible fractions", {
  # Ge escape only for parents above the Ge K edge (11.10 keV)
  below <- xrf_escape_peaks(data.frame(element = "As", energy_kev = 10.53), detector_type = "HPGe")
  expect_equal(nrow(below), 0)   # As Ka is below the Ge K edge -> no escape

  above <- xrf_escape_peaks(data.frame(element = "Se", energy_kev = 12.65,
                                       relative_peak_intensity = 1), detector_type = "HPGe")
  expect_true(nrow(above) >= 1)
  # Ge Ka escape sits ~9.886 keV below the parent and is a large fraction near the edge
  ka <- above[above$trans == "escape_GeKa", ]
  expect_equal(ka$energy_kev, 12.65 - 9.886, tolerance = 0.05)
  expect_gt(ka$relative_peak_intensity, 0.03)
  expect_true(all(above$relative_peak_intensity > 0 & above$relative_peak_intensity < 1))

  # Si escape is small (~0.4%)
  si <- xrf_escape_peaks(data.frame(element = "Fe", energy_kev = 6.40,
                                    relative_peak_intensity = 1), detector_type = "SDD")
  expect_true(all(si$relative_peak_intensity < 0.02))

  # CdTe produces both Cd and Te escapes for a high-energy parent
  cdte <- xrf_escape_peaks(data.frame(element = "Pb", energy_kev = 74.97,
                                      relative_peak_intensity = 1), detector_type = "CdTe")
  expect_true(any(grepl("Cd", cdte$trans)) && any(grepl("Te", cdte$trans)))
})

test_that("SDD preset is a 450 um active layer and active_thickness_um overrides it", {
  # the modern-SDD default the deconvolution assumes when efficiency = TRUE
  expect_equal(xrf_detector_presets()$active_thickness_um[xrf_detector_presets()$type == "SDD"], 450)
  # thinner Si is more transparent at high energy
  expect_lt(xrf_detector_efficiency(30, "SDD", active_thickness_um = 50),
            xrf_detector_efficiency(30, "SDD", active_thickness_um = 2000))
})

test_that("active_thickness_um is threaded through the deconvolution efficiency model", {
  # A single element's data-space height/area is largely invariant to a uniform efficiency scale (the
  # fit coefficient absorbs it). The thickness bites on the INTRA-element line ratio: a wide grid
  # spanning Ba L (~4.5 keV) and K (~32 keV) with data at both makes the L:K template balance -- which
  # high-energy transmission reshapes -- constrain the single Ba coefficient. A dropped (unthreaded)
  # argument would give identical fits; this guards the plumbing, not just the physics.
  e <- seq(2, 40, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  y <- xrftools:::gaussian_fun(e, 4.47, sig(4.47), 500) +
    xrftools:::gaussian_fun(e, 32.19, sig(32.19), 500)
  peaks <- xrf_energies("Ba", 60)
  fit <- function(t, cache = FALSE) {
    d <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "SDD",
           efficiency = TRUE, active_thickness_um = t, cache_templates = cache)
    d$peaks$height[d$peaks$element == "Ba"]
  }
  h_thin <- fit(50); h_thick <- fit(3000)
  expect_gt(h_thin, 0)
  expect_gt(h_thick, 0)
  expect_gt(abs(h_thin - h_thick), 0.1 * h_thick)   # thickness genuinely reaches the model

  # NULL uses the detector preset -> now the 450 um modern SDD -> identical to an explicit 450
  expect_equal(fit(NULL), fit(450))

  # the single-slot template cache must key on the efficiency-weighted templates: a run cached at one
  # thickness must never be silently reused for a different one (guards cross-batch reuse in a session)
  expect_equal(fit(50, cache = TRUE), h_thin)
  expect_equal(fit(3000, cache = TRUE), h_thick)   # back-to-back with cache on: no stale reuse
})

test_that("efficiency and escape flow through the deconvolution", {
  e <- seq(1, 15, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "HPGe")
  # Se Ka + its Ge escape satellite
  y <- xrftools:::gaussian_fun(e, 12.65, sig(12.65), 1000) +
    xrftools:::gaussian_fun(e, 12.65 - 9.886, sig(12.65 - 9.886), 80)
  peaks <- xrf_energies(c("Se", "Ge", "Zn"), 30)

  d <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = peaks, detector_type = "HPGe",
                                              efficiency = TRUE, escape = TRUE)
  expect_s3_class(d, "deconvolution_fit")
  expect_true(all(d$peaks$height >= 0))
  expect_gt(d$peaks$height[d$peaks$element == "Se"], 0)
})
