context("engine")

g <- function(...) xrftools:::gaussian_fun(...)

test_that("Hypermet line shape is a Gaussian by default and adds a low-energy tail (#20)", {
  e <- seq(5, 8, 0.005)
  expect_equal(xrf_lineshape(e, 6.4, 0.09, 1, tail = 0, step = 0), g(e, 6.4, 0.09, 1))
  lt <- xrf_lineshape(e, 6.4, 0.09, 1, tail = 0.2, beta = 0.12)
  lg <- xrf_lineshape(e, 6.4, 0.09, 1, tail = 0)
  low <- e < 6.4 - 0.3
  expect_gt(sum(lt[low]), 10 * sum(lg[low]))     # tail is on the low-energy side
  expect_true(all(is.finite(lt)))
})

test_that("windowed template build matches the full Gaussian, and tail changes peak_area (#19/#20)", {
  e <- seq(1, 20, 0.02)
  y <- g(e, 6.4, 0.09, 500) + g(e, 8.05, 0.09, 200)
  pk <- tibble::tibble(element = c("Fe", "Cu"), energy_kev = c(6.4, 8.05),
                       relative_peak_intensity = 1)
  d <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = pk, default_sigma = 0.09)
  h <- setNames(d$peaks$height, d$peaks$element)
  expect_equal(unname(h["Fe"]), 500, tolerance = 0.01)
  expect_equal(unname(h["Cu"]), 200, tolerance = 0.01)
  dt <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = pk, default_sigma = 0.09, tail = 0.1)
  expect_true(all(dt$peaks$peak_area >= d$peaks$peak_area * 0.99))   # tail adds area
})

test_that("template caching returns identical results (#15)", {
  e <- seq(1, 20, 0.02); pk <- tibble::tibble(element = "Fe", energy_kev = 6.4,
                                              relative_peak_intensity = 1)
  y <- g(e, 6.4, 0.09, 300)
  assign("key", NULL, envir = xrftools:::.xrf_template_cache)
  a <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = pk, default_sigma = 0.09,
                                              cache_templates = TRUE)
  expect_false(is.null(xrftools:::.xrf_template_cache$key))
  b <- xrf_deconvolute_gaussian_least_squares(e, 2 * y, peaks = pk, default_sigma = 0.09,
                                              cache_templates = TRUE)   # cache hit, only RHS changes
  expect_equal(2 * a$peaks$height, b$peaks$height)
})

test_that("rank/condition diagnostics: condition number + NA for aliased templates (#22)", {
  e <- seq(1, 20, 0.02)
  d <- xrf_deconvolute_gaussian_least_squares(e, g(e, 6.4, 0.09, 300),
                                              peaks = tibble::tibble(element = "Fe", energy_kev = 6.4,
                                                                     relative_peak_intensity = 1),
                                              default_sigma = 0.09)
  expect_true("condition_number" %in% colnames(d$fit))
  expect_true(is.finite(d$fit$condition_number))

  # two identical-energy templates are not separable -> warn, aliased reported NA (unconstrained)
  pk_dup <- tibble::tibble(element = c("A", "B"), energy_kev = c(6.4, 6.4),
                           relative_peak_intensity = 1)
  expect_warning(
    d_dup <- xrf_deconvolute_gaussian_least_squares(e, g(e, 6.4, 0.09, 300), peaks = pk_dup,
                                                    default_sigma = 0.09, nonneg = FALSE),
    "rank-deficient"
  )
  expect_true(any(is.na(d_dup$peaks$height)))
})

test_that("calibration refinement recovers a gain error (#16)", {
  e <- seq(1, 20, 0.02)
  yg <- g(e, 6.4 * 1.03, 0.09, 500) + g(e, 8.05 * 1.03, 0.09, 200)   # 3% gain drift in the data
  pk <- tibble::tibble(element = c("Fe", "Cu"), energy_kev = c(6.4, 8.05),
                       relative_peak_intensity = 1)
  d0 <- xrf_deconvolute_gaussian_least_squares(e, yg, peaks = pk, default_sigma = 0.09,
                                               refine_calibration = FALSE)
  d1 <- xrf_deconvolute_gaussian_least_squares(e, yg, peaks = pk, default_sigma = 0.09,
                                               refine_calibration = TRUE)
  expect_gt(d1$fit$r2, d0$fit$r2)
  expect_gt(d1$fit$r2, 0.99)
})

test_that("sum-peak templates are added and are non-negative (#21)", {
  e <- seq(1, 20, 0.02)
  ys <- g(e, 6.4, 0.09, 500) + g(e, 12.8, sqrt(2) * 0.09, 40)   # Fe Ka + 2x pile-up
  pk <- xrf_energies(c("Fe", "Se", "Kr"), 30)
  d <- xrf_deconvolute_gaussian_least_squares(e, ys, peaks = pk, detector_type = "SDD",
                                              sum_peaks = TRUE)
  expect_true(any(grepl("^sum_", d$peaks$element)))
  expect_true(all(d$peaks$height >= 0))
})

test_that("two-pass pile-up correction adds fixed-amplitude coincidence peaks (E3)", {
  e <- seq(1, 20, 0.02); lt <- 30; tau <- 5e-6
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  A_fe <- 5000 * sig(6.40) * sqrt(2 * pi) * lt
  A_pu <- tau / lt * A_fe^2
  s_pu <- sqrt(2) * sig(6.40)
  truth <- g(e, 6.40, sig(6.40), 5000) + g(e, 12.8, s_pu, (A_pu / lt) / (s_pu * sqrt(2 * pi)))
  set.seed(9); counts <- rpois(length(e), pmax(truth, 0) * lt)
  pk <- xrf_energies(c("Fe", "Kr"), 30)

  d <- xrf_deconvolute_gaussian_least_squares(e, counts / lt, peaks = pk, detector_type = "SDD",
                                              counts = counts, livetime = lt, pileup_tau = tau)
  expect_true(any(grepl("^pileup_", d$peaks$element)))
  pu <- d$peaks[grepl("^pileup_", d$peaks$element), ]
  expect_true(all(pu$peak_area > 0))
  # the Fe self-pile-up sits at 2 x Fe Ka ~ 12.8 keV
  expect_true(any(abs(pu$primary_energy_kev - 12.8) < 0.2))
})

test_that("energy-aware SNIP baseline runs quietly (#14)", {
  spec <- read_xrf_example(.which = 7)
  expect_silent(
    ba <- xrf_add_baseline_snip(spec, .values = .spectra$cps, iterations = 20, energy_aware = TRUE)
  )
  bl <- ba$.spectra[[1]]$baseline
  expect_true(all(is.finite(bl)))
  expect_equal(length(bl), nrow(ba$.spectra[[1]]))
})

test_that("discreteFilter iterative convergence uses an RMS metric (#23)", {
  set.seed(1); v <- cumsum(rnorm(200))
  # a positive epsilon must not trip on iteration 1 (the old signed-mean bug)
  converged <- xrftools:::discreteFilterIterative(v, xrf_filter_gaussian(7), 50, 1e-8)
  one_iter <- xrftools:::discreteFilterIterative(v, xrf_filter_gaussian(7), 1, -1)
  expect_false(isTRUE(all.equal(converged, one_iter)))
})
