context("quant")

test_that("fundamental-parameters quantification recovers known concentrations (no matrix)", {
  E0 <- 40; det <- "SDD"
  Ctrue <- c(Fe = 0.40, Ca = 0.25, Ti = 0.10, K = 0.12, Sr = 0.08, Zn = 0.05)
  Ctrue <- Ctrue / sum(Ctrue)
  s <- xrf_fp_sensitivity(names(Ctrue), E0, detector_type = det)
  expect_true(all(is.finite(s$sensitivity) & s$sensitivity > 0))

  # generate areas = C * S (no matrix), quantify without self-absorption -> exact recovery
  pk <- data.frame(element = s$element, peak_area = Ctrue[s$element] * s$sensitivity)
  q <- xrf_quantify(pk, E0, detector_type = det, self_absorption = FALSE)
  expect_equal(q$concentration[match(names(Ctrue), q$element)], unname(Ctrue), tolerance = 1e-8)
  expect_equal(sum(q$concentration), 1, tolerance = 1e-8)
})

test_that("self-absorption correction inverts a matrix-attenuated round trip", {
  E0 <- 40; det <- "SDD"
  Ctrue <- c(Fe = 0.5, Ca = 0.3, Sr = 0.2)
  s <- xrf_fp_sensitivity(names(Ctrue), E0, detector_type = det)
  si <- sin(45 * pi / 180)
  # self-absorption attenuates by TOTAL mu (matches the corrected xrf_quantify); synthesise the forward
  # model the same way so the correction should invert it back to Ctrue.
  mu_at <- function(en) sum(Ctrue * vapply(names(Ctrue),
                                           function(el) xrftools:::.xrf_element_total_mu(el, en), numeric(1)))
  A <- 1 / (mu_at(E0) / si + vapply(s$primary_energy_kev, mu_at, numeric(1)) / si)
  pk <- data.frame(element = s$element, peak_area = Ctrue[s$element] * s$sensitivity * A)

  q <- xrf_quantify(pk, E0, detector_type = det, self_absorption = TRUE,
                    incidence_deg = 45, takeoff_deg = 45, iterations = 20)
  expect_equal(q$concentration[match(names(Ctrue), q$element)], unname(Ctrue), tolerance = 1e-4)
})

test_that("secondary fluorescence lowers the enhanced element's concentration (E2)", {
  # Fe Ka (6.40 keV) is above the Cr K edge (5.99 keV), so Fe enhances Cr. Correcting for it must
  # reduce the inferred Cr concentration relative to the primary-only result.
  pk <- data.frame(element = c("Cr", "Fe", "Ni"), peak_area = c(300, 500, 50))
  q_no  <- xrf_quantify(pk, 30, detector_type = "SDD", secondary_fluorescence = FALSE)
  q_sec <- xrf_quantify(pk, 30, detector_type = "SDD", secondary_fluorescence = TRUE)
  cr <- function(q) q$concentration[q$element == "Cr"]
  expect_lt(cr(q_sec), cr(q_no))
  expect_equal(sum(q_sec$concentration), 1, tolerance = 1e-6)
})

test_that("observed mass is un-normalized, matrix-decoupled, and equals A_i/S_i", {
  pk <- data.frame(element = c("Fe", "Ca", "K"), peak_area = c(500, 150, 80))
  om <- xrf_observed_mass(pk, 30, detector_type = "SDD")
  s <- xrf_fp_sensitivity(c("Fe", "Ca", "K"), 30, detector_type = "SDD")
  expect_equal(om$observed_mass, pk$peak_area / s$sensitivity, tolerance = 1e-8)

  # adding a new element does NOT change the others (unlike normalized FP)
  pk2 <- rbind(pk, data.frame(element = "Zn", peak_area = 300))
  om2 <- xrf_observed_mass(pk2, 30, detector_type = "SDD")
  fe <- function(x) x$observed_mass[x$element == "Fe"]
  expect_equal(fe(om), fe(om2))
  q <- xrf_quantify(pk, 30, detector_type = "SDD")
  q2 <- xrf_quantify(pk2, 30, detector_type = "SDD")
  expect_false(isTRUE(all.equal(q$concentration[q$element == "Fe"],
                                q2$concentration[q2$element == "Fe"])))   # normalized DOES change

  # optional Compton normalization needs a fitted scatter peak
  expect_error(xrf_observed_mass(pk, 30, detector_type = "SDD", normalization = "compton"), "scatter")
})

test_that("generalized self-absorption depth-corrects without coupling elements (a)", {
  pk <- data.frame(element = c("Fe", "Ca", "Si"), peak_area = c(500, 150, 300))
  raw <- xrf_observed_mass(pk, 30, detector_type = "SDD", self_absorption = "none")
  gen <- xrf_observed_mass(pk, 30, detector_type = "SDD", self_absorption = "generalized",
                           matrix = "silicate")
  ratio <- gen$observed_mass / raw$observed_mass
  # low-energy Si (1.74 keV, heavily absorbed) gets the largest depth boost; high-energy Fe the least
  expect_gt(ratio[gen$element == "Si"], ratio[gen$element == "Fe"])
  # still decoupled: adding an element does not change Fe
  gen2 <- xrf_observed_mass(rbind(pk, data.frame(element = "Zn", peak_area = 999)), 30,
                            detector_type = "SDD", self_absorption = "generalized")
  expect_equal(gen$observed_mass[gen$element == "Fe"], gen2$observed_mass[gen2$element == "Fe"])
  # a custom composition works; an unknown built-in name errors
  expect_true(is.finite(xrf_observed_mass(pk, 30, detector_type = "SDD",
                                          self_absorption = "generalized",
                                          matrix = c(O = 0.5, Fe = 0.5))$observed_mass[1]))
  expect_error(xrf_observed_mass(pk, 30, detector_type = "SDD", self_absorption = "generalized",
                                 matrix = "unobtainium"), "Unknown generic matrix")
})

test_that("xrf_calibrate recovers per-element factors and feeds xrf_observed_mass (b)", {
  std1 <- data.frame(element = c("Fe", "Ca", "Ti"), peak_area = c(400, 120, 60))
  std2 <- data.frame(element = c("Fe", "Ca", "Ti"), peak_area = c(800, 60, 180))
  o1 <- xrf_observed_mass(std1, 30, detector_type = "SDD")$observed_mass
  o2 <- xrf_observed_mass(std2, 30, detector_type = "SDD")$observed_mass
  ktrue <- c(Fe = 2.0, Ca = 0.5, Ti = 3.0)
  vals <- list(stats::setNames(ktrue * o1, c("Fe", "Ca", "Ti")),
               stats::setNames(ktrue * o2, c("Fe", "Ca", "Ti")))

  k <- xrf_calibrate(list(std1, std2), vals, 30, detector_type = "SDD")
  expect_equal(unname(k[c("Fe", "Ca", "Ti")]), unname(ktrue[c("Fe", "Ca", "Ti")]), tolerance = 1e-6)
  expect_equal(unname(attr(k, "n_standards")[c("Fe", "Ca", "Ti")]), c(2L, 2L, 2L))

  # data-frame `values` form gives the same answer
  vdf <- data.frame(element = c("Fe", "Ca", "Ti"), s1 = ktrue * o1, s2 = ktrue * o2)
  k2 <- xrf_calibrate(list(std1, std2), vdf, 30, detector_type = "SDD")
  expect_equal(unname(k[c("Fe", "Ca", "Ti")]), unname(k2[c("Fe", "Ca", "Ti")]), tolerance = 1e-8)

  # calibration must be fitted and applied with the same settings -> observed * k
  unk <- data.frame(element = "Fe", peak_area = 600)
  cal <- xrf_observed_mass(unk, 30, detector_type = "SDD", calibration = k)
  raw <- xrf_observed_mass(unk, 30, detector_type = "SDD")
  expect_equal(cal$observed_mass, raw$observed_mass * unname(k["Fe"]), tolerance = 1e-8)

  # a single standard given as a lone named vector is accepted
  k1 <- xrf_calibrate(list(std1), stats::setNames(ktrue[c("Fe","Ca","Ti")] * o1, c("Fe","Ca","Ti")),
                      30, detector_type = "SDD")
  expect_true(all(is.finite(k1[c("Fe", "Ca", "Ti")])))
  expect_false(is.null(attr(k1, "settings")))
})

test_that("calibration does not silently mix relative and absolute scales", {
  pk <- data.frame(element = c("Fe", "Ca", "Cr"), peak_area = c(500, 150, 80))
  k <- c(Fe = 2.0, Ca = 0.5)                                # Cr not calibrated
  attr(k, "settings") <- list(self_absorption = "none", matrix = "silicate", normalization = "none")
  # uncalibrated Cr comes back NA (not silently multiplied by 1), with a warning
  expect_warning(res <- xrf_observed_mass(pk, 30, detector_type = "SDD", calibration = k),
                 "No calibration factor")
  expect_true(is.na(res$observed_mass[res$element == "Cr"]))
  expect_true(is.finite(res$observed_mass[res$element == "Fe"]))

  # an unnamed calibration vector is rejected (positional mistake, not silently ignored)
  expect_error(xrf_observed_mass(pk, 30, detector_type = "SDD", calibration = c(2, 0.5, 1)), "named")

  # applying with different settings than the fit warns
  attr(k, "settings")$self_absorption <- "generalized"
  expect_warning(xrf_observed_mass(data.frame(element = "Fe", peak_area = 500), 30,
                                   detector_type = "SDD", self_absorption = "none", calibration = k),
                 "different")
})

test_that("tertiary fluorescence adds a small further correction beyond secondary", {
  pk <- data.frame(element = c("Cr", "Fe", "Ni"), peak_area = c(300, 500, 200))
  cr <- function(...) {
    q <- xrf_quantify(pk, 30, detector_type = "SDD", ...)
    q$concentration[q$element == "Cr"]
  }
  c1 <- cr(secondary_fluorescence = FALSE)
  c2 <- cr(secondary_fluorescence = TRUE)
  c3 <- cr(tertiary_fluorescence = TRUE)                 # implies secondary
  expect_lt(c2, c1)                                       # secondary lowers enhanced Cr
  expect_lt(c3, c2)                                       # tertiary lowers it a little more
  expect_lt(abs(c3 - c2), abs(c2 - c1))                  # ... but by a smaller amount
})

test_that("Ebel tube spectrum and polychromatic excitation (L2)", {
  e <- seq(1, 40, 0.1)
  N <- xrf_tube_spectrum(xrf_tube("Rh", kv = 40, filter = "Al 50"), e)
  expect_true(all(is.finite(N)))
  expect_true(all(N[e >= 40] == 0))                     # nothing at/above the endpoint
  expect_gt(N[which.min(abs(e - 20.2))], 5 * N[which.min(abs(e - 15))])  # Rh Ka towers over continuum
  # polychromatic sensitivity differs from monochromatic
  s_mono <- xrf_fp_sensitivity(c("Fe", "Sr"), 40, detector_type = "SDD")
  s_poly <- xrf_fp_sensitivity(c("Fe", "Sr"), 40, detector_type = "SDD", tube = xrf_tube("Rh", kv = 40))
  expect_false(isTRUE(all.equal(s_mono$sensitivity, s_poly$sensitivity)))
  expect_true(all(is.finite(s_poly$sensitivity)))
})

test_that("oxide stoichiometry is opt-in and adds oxygen by difference (L3)", {
  pk <- data.frame(element = c("Si", "Al", "Ca", "Fe"), peak_area = c(400, 200, 150, 250))
  q_metal <- xrf_quantify(pk, 30, detector_type = "SDD")                  # default: no oxide
  q_oxide <- xrf_quantify(pk, 30, detector_type = "SDD", oxide = TRUE)
  expect_false("O" %in% q_metal$element)                                  # off by default
  expect_true("O" %in% q_oxide$element)
  expect_gt(q_oxide$concentration[q_oxide$element == "O"], 0)
  expect_equal(sum(q_oxide$concentration), 1, tolerance = 1e-6)
  # a named override sets the oxygen-per-cation ratios
  q_ov <- xrf_quantify(pk, 30, detector_type = "SDD", oxide = c(Si = 2, Al = 1.5, Ca = 1, Fe = 1.5))
  expect_true("O" %in% q_ov$element)
})

test_that("Compton normalization divides by the fitted Compton area", {
  # build a spectrum with two element peaks + a Compton scatter bump, fit with a tube
  e <- seq(2, 25, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  co <- 20.216 / (1 + (20.216 / 510.999) * (1 - cos(135 * pi / 180)))
  y <- xrftools:::gaussian_fun(e, 6.40, sig(6.40), 500) +
    xrftools:::gaussian_fun(e, 8.64, sig(8.64), 200) +
    xrftools:::gaussian_fun(e, co, 2 * sig(co), 300)
  d <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = xrf_energies(c("Fe", "Zn"), 40),
                                              detector_type = "SDD",
                                              tube = xrf_tube("Rh", kv = 40),
                                              geometry = xrf_geometry(scatter_angle_deg = 135))
  cn <- xrf_compton_normalize(d)
  expect_true(all(c("peak_area_norm", "peak_area_norm_se") %in% colnames(cn)))
  comp_area <- d$peaks$peak_area[d$peaks$element == "scatter_compton"]
  fe <- cn[cn$element == "Fe", ]
  expect_equal(fe$peak_area_norm, fe$peak_area / comp_area, tolerance = 1e-8)

  # errors when there is no scatter fitted
  d_no <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = xrf_energies(c("Fe", "Zn"), 40))
  expect_error(xrf_compton_normalize(d_no), "scatter")
})

test_that("active_thickness_um is threaded into the FP sensitivity (and thus xrf_observed_mass)", {
  # A thicker active layer catches more high-energy photons -> higher sensitivity. The effect is far larger
  # at high energy (Ba K ~32 keV, thin Si is transparent) than at low energy (Fe Ka 6.4 keV, mostly absorbed).
  s_thin  <- xrf_fp_sensitivity(c("Fe", "Ba"), 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 50)
  s_thick <- xrf_fp_sensitivity(c("Fe", "Ba"), 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 3000)
  expect_gt(s_thick$sensitivity[s_thick$element == "Ba"], s_thin$sensitivity[s_thin$element == "Ba"])
  ba_ratio <- s_thick$sensitivity[s_thick$element == "Ba"] / s_thin$sensitivity[s_thin$element == "Ba"]
  fe_ratio <- s_thick$sensitivity[s_thick$element == "Fe"] / s_thin$sensitivity[s_thin$element == "Fe"]
  expect_gt(ba_ratio, fe_ratio * 5)   # thickness bites much harder at high energy
  # NULL uses the detector preset (SDD = 450 um) -> identical to an explicit 450
  s_pre <- xrf_fp_sensitivity("Ba", 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = NULL)
  s_450 <- xrf_fp_sensitivity("Ba", 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 450)
  expect_equal(s_pre$sensitivity, s_450$sensitivity)

  # it flows through the public mass function too: thinner detector -> less sensitivity -> larger inferred mass
  pk <- data.frame(element = c("Fe", "Ba"), peak_area = c(1000, 1000))
  m_thin  <- xrf_observed_mass(pk, 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 50)
  m_thick <- xrf_observed_mass(pk, 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 3000)
  expect_gt(m_thin$observed_mass[m_thin$element == "Ba"], m_thick$observed_mass[m_thick$element == "Ba"])
})
