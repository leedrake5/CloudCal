context("quant")

test_that("fundamental-parameters quantification recovers known concentrations (no matrix)", {
  E0 <- 40; det <- "SDD"
  Ctrue <- c(Fe = 0.40, Ca = 0.25, Ti = 0.10, K = 0.12, Sr = 0.08, Zn = 0.05)
  Ctrue <- Ctrue / sum(Ctrue)
  s <- xrf_fp_sensitivity(names(Ctrue), E0, detector_type = det)
  expect_true(all(is.finite(s$sensitivity) & s$sensitivity > 0))

  # generate areas = C * S (no matrix), quantify without self-absorption -> exact recovery
  pk <- data.frame(element = s$element, peak_area = Ctrue[s$element] * s$sensitivity)
  q <- xrf_quantify(pk, E0, detector_type = det, self_absorption = FALSE)
  expect_equal(q$concentration[match(names(Ctrue), q$element)], unname(Ctrue), tolerance = 1e-8)
  expect_equal(sum(q$concentration), 1, tolerance = 1e-8)
})

test_that("self-absorption correction inverts a matrix-attenuated round trip", {
  E0 <- 40; det <- "SDD"
  Ctrue <- c(Fe = 0.5, Ca = 0.3, Sr = 0.2)
  s <- xrf_fp_sensitivity(names(Ctrue), E0, detector_type = det)
  si <- sin(45 * pi / 180)
  # self-absorption attenuates by TOTAL mu (matches the corrected xrf_quantify); synthesise the forward
  # model the same way so the correction should invert it back to Ctrue.
  mu_at <- function(en) sum(Ctrue * vapply(names(Ctrue),
                                           function(el) xrftools:::.xrf_element_total_mu(el, en), numeric(1)))
  A <- 1 / (mu_at(E0) / si + vapply(s$primary_energy_kev, mu_at, numeric(1)) / si)
  pk <- data.frame(element = s$element, peak_area = Ctrue[s$element] * s$sensitivity * A)

  q <- xrf_quantify(pk, E0, detector_type = det, self_absorption = TRUE,
                    incidence_deg = 45, takeoff_deg = 45, iterations = 20)
  expect_equal(q$concentration[match(names(Ctrue), q$element)], unname(Ctrue), tolerance = 1e-4)
})

test_that("secondary fluorescence lowers the enhanced element's concentration (E2)", {
  # Fe Ka (6.40 keV) is above the Cr K edge (5.99 keV), so Fe enhances Cr. Correcting for it must
  # reduce the inferred Cr concentration relative to the primary-only result.
  pk <- data.frame(element = c("Cr", "Fe", "Ni"), peak_area = c(300, 500, 50))
  q_no  <- xrf_quantify(pk, 30, detector_type = "SDD", secondary_fluorescence = FALSE)
  q_sec <- xrf_quantify(pk, 30, detector_type = "SDD", secondary_fluorescence = TRUE)
  cr <- function(q) q$concentration[q$element == "Cr"]
  expect_lt(cr(q_sec), cr(q_no))
  expect_equal(sum(q_sec$concentration), 1, tolerance = 1e-6)
})

test_that("observed mass is un-normalized, matrix-decoupled, and equals A_i/S_i", {
  pk <- data.frame(element = c("Fe", "Ca", "K"), peak_area = c(500, 150, 80))
  om <- xrf_observed_mass(pk, 30, detector_type = "SDD")
  s <- xrf_fp_sensitivity(c("Fe", "Ca", "K"), 30, detector_type = "SDD")
  expect_equal(om$observed_mass, pk$peak_area / s$sensitivity, tolerance = 1e-8)

  # adding a new element does NOT change the others (unlike normalized FP)
  pk2 <- rbind(pk, data.frame(element = "Zn", peak_area = 300))
  om2 <- xrf_observed_mass(pk2, 30, detector_type = "SDD")
  fe <- function(x) x$observed_mass[x$element == "Fe"]
  expect_equal(fe(om), fe(om2))
  q <- xrf_quantify(pk, 30, detector_type = "SDD")
  q2 <- xrf_quantify(pk2, 30, detector_type = "SDD")
  expect_false(isTRUE(all.equal(q$concentration[q$element == "Fe"],
                                q2$concentration[q2$element == "Fe"])))   # normalized DOES change

  # optional Compton normalization needs a fitted scatter peak
  expect_error(xrf_observed_mass(pk, 30, detector_type = "SDD", normalization = "compton"), "scatter")
})

test_that("generalized self-absorption depth-corrects without coupling elements (a)", {
  pk <- data.frame(element = c("Fe", "Ca", "Si"), peak_area = c(500, 150, 300))
  raw <- xrf_observed_mass(pk, 30, detector_type = "SDD", self_absorption = "none")
  gen <- xrf_observed_mass(pk, 30, detector_type = "SDD", self_absorption = "generalized",
                           matrix = "silicate")
  ratio <- gen$observed_mass / raw$observed_mass
  # low-energy Si (1.74 keV, heavily absorbed) gets the largest depth boost; high-energy Fe the least
  expect_gt(ratio[gen$element == "Si"], ratio[gen$element == "Fe"])
  # still decoupled: adding an element does not change Fe
  gen2 <- xrf_observed_mass(rbind(pk, data.frame(element = "Zn", peak_area = 999)), 30,
                            detector_type = "SDD", self_absorption = "generalized")
  expect_equal(gen$observed_mass[gen$element == "Fe"], gen2$observed_mass[gen2$element == "Fe"])
  # a custom composition works; an unknown built-in name errors
  expect_true(is.finite(xrf_observed_mass(pk, 30, detector_type = "SDD",
                                          self_absorption = "generalized",
                                          matrix = c(O = 0.5, Fe = 0.5))$observed_mass[1]))
  expect_error(xrf_observed_mass(pk, 30, detector_type = "SDD", self_absorption = "generalized",
                                 matrix = "unobtainium"), "Unknown generic matrix")
})

test_that("xrf_calibrate recovers per-element factors and feeds xrf_observed_mass (b)", {
  std1 <- data.frame(element = c("Fe", "Ca", "Ti"), peak_area = c(400, 120, 60))
  std2 <- data.frame(element = c("Fe", "Ca", "Ti"), peak_area = c(800, 60, 180))
  o1 <- xrf_observed_mass(std1, 30, detector_type = "SDD")$observed_mass
  o2 <- xrf_observed_mass(std2, 30, detector_type = "SDD")$observed_mass
  ktrue <- c(Fe = 2.0, Ca = 0.5, Ti = 3.0)
  vals <- list(stats::setNames(ktrue * o1, c("Fe", "Ca", "Ti")),
               stats::setNames(ktrue * o2, c("Fe", "Ca", "Ti")))

  k <- xrf_calibrate(list(std1, std2), vals, 30, detector_type = "SDD")
  expect_equal(unname(k[c("Fe", "Ca", "Ti")]), unname(ktrue[c("Fe", "Ca", "Ti")]), tolerance = 1e-6)
  expect_equal(unname(attr(k, "n_standards")[c("Fe", "Ca", "Ti")]), c(2L, 2L, 2L))

  # data-frame `values` form gives the same answer
  vdf <- data.frame(element = c("Fe", "Ca", "Ti"), s1 = ktrue * o1, s2 = ktrue * o2)
  k2 <- xrf_calibrate(list(std1, std2), vdf, 30, detector_type = "SDD")
  expect_equal(unname(k[c("Fe", "Ca", "Ti")]), unname(k2[c("Fe", "Ca", "Ti")]), tolerance = 1e-8)

  # calibration must be fitted and applied with the same settings -> observed * k
  unk <- data.frame(element = "Fe", peak_area = 600)
  cal <- xrf_observed_mass(unk, 30, detector_type = "SDD", calibration = k)
  raw <- xrf_observed_mass(unk, 30, detector_type = "SDD")
  expect_equal(cal$observed_mass, raw$observed_mass * unname(k["Fe"]), tolerance = 1e-8)

  # a single standard given as a lone named vector is accepted
  k1 <- xrf_calibrate(list(std1), stats::setNames(ktrue[c("Fe","Ca","Ti")] * o1, c("Fe","Ca","Ti")),
                      30, detector_type = "SDD")
  expect_true(all(is.finite(k1[c("Fe", "Ca", "Ti")])))
  expect_false(is.null(attr(k1, "settings")))
})

test_that("calibration does not silently mix relative and absolute scales", {
  pk <- data.frame(element = c("Fe", "Ca", "Cr"), peak_area = c(500, 150, 80))
  k <- c(Fe = 2.0, Ca = 0.5)                                # Cr not calibrated
  attr(k, "settings") <- list(self_absorption = "none", matrix = "silicate", normalization = "none")
  # uncalibrated Cr comes back NA (not silently multiplied by 1), with a warning
  expect_warning(res <- xrf_observed_mass(pk, 30, detector_type = "SDD", calibration = k),
                 "No calibration factor")
  expect_true(is.na(res$observed_mass[res$element == "Cr"]))
  expect_true(is.finite(res$observed_mass[res$element == "Fe"]))

  # an unnamed calibration vector is rejected (positional mistake, not silently ignored)
  expect_error(xrf_observed_mass(pk, 30, detector_type = "SDD", calibration = c(2, 0.5, 1)), "named")

  # applying with different settings than the fit warns
  attr(k, "settings")$self_absorption <- "generalized"
  expect_warning(xrf_observed_mass(data.frame(element = "Fe", peak_area = 500), 30,
                                   detector_type = "SDD", self_absorption = "none", calibration = k),
                 "different")
})

test_that("tertiary fluorescence adds a small further correction beyond secondary", {
  pk <- data.frame(element = c("Cr", "Fe", "Ni"), peak_area = c(300, 500, 200))
  cr <- function(...) {
    q <- xrf_quantify(pk, 30, detector_type = "SDD", ...)
    q$concentration[q$element == "Cr"]
  }
  c1 <- cr(secondary_fluorescence = FALSE)
  c2 <- cr(secondary_fluorescence = TRUE)
  c3 <- cr(tertiary_fluorescence = TRUE)                 # implies secondary
  expect_lt(c2, c1)                                       # secondary lowers enhanced Cr
  expect_lt(c3, c2)                                       # tertiary lowers it a little more
  expect_lt(abs(c3 - c2), abs(c2 - c1))                  # ... but by a smaller amount
})

test_that("Ebel tube spectrum and polychromatic excitation (L2)", {
  e <- seq(1, 40, 0.1)
  N <- xrf_tube_spectrum(xrf_tube("Rh", kv = 40, filter = "Al 50"), e)
  expect_true(all(is.finite(N)))
  expect_true(all(N[e >= 40] == 0))                     # nothing at/above the endpoint
  expect_gt(N[which.min(abs(e - 20.2))], 5 * N[which.min(abs(e - 15))])  # Rh Ka towers over continuum
  # polychromatic sensitivity differs from monochromatic
  s_mono <- xrf_fp_sensitivity(c("Fe", "Sr"), 40, detector_type = "SDD")
  s_poly <- xrf_fp_sensitivity(c("Fe", "Sr"), 40, detector_type = "SDD", tube = xrf_tube("Rh", kv = 40))
  expect_false(isTRUE(all.equal(s_mono$sensitivity, s_poly$sensitivity)))
  expect_true(all(is.finite(s_poly$sensitivity)))
})

test_that("oxide stoichiometry is opt-in and adds oxygen by difference (L3)", {
  pk <- data.frame(element = c("Si", "Al", "Ca", "Fe"), peak_area = c(400, 200, 150, 250))
  q_metal <- xrf_quantify(pk, 30, detector_type = "SDD")                  # default: no oxide
  q_oxide <- xrf_quantify(pk, 30, detector_type = "SDD", oxide = TRUE)
  expect_false("O" %in% q_metal$element)                                  # off by default
  expect_true("O" %in% q_oxide$element)
  expect_gt(q_oxide$concentration[q_oxide$element == "O"], 0)
  expect_equal(sum(q_oxide$concentration), 1, tolerance = 1e-6)
  # a named override sets the oxygen-per-cation ratios
  q_ov <- xrf_quantify(pk, 30, detector_type = "SDD", oxide = c(Si = 2, Al = 1.5, Ca = 1, Fe = 1.5))
  expect_true("O" %in% q_ov$element)
})

test_that("Compton normalization divides by the fitted Compton area", {
  # build a spectrum with two element peaks + a Compton scatter bump, fit with a tube
  e <- seq(2, 25, 0.02)
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD")
  co <- 20.216 / (1 + (20.216 / 510.999) * (1 - cos(135 * pi / 180)))
  y <- xrftools:::gaussian_fun(e, 6.40, sig(6.40), 500) +
    xrftools:::gaussian_fun(e, 8.64, sig(8.64), 200) +
    xrftools:::gaussian_fun(e, co, 2 * sig(co), 300)
  d <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = xrf_energies(c("Fe", "Zn"), 40),
                                              detector_type = "SDD",
                                              tube = xrf_tube("Rh", kv = 40),
                                              geometry = xrf_geometry(scatter_angle_deg = 135))
  cn <- xrf_compton_normalize(d)
  expect_true(all(c("peak_area_norm", "peak_area_norm_se") %in% colnames(cn)))
  comp_area <- d$peaks$peak_area[d$peaks$element == "scatter_compton"]
  fe <- cn[cn$element == "Fe", ]
  expect_equal(fe$peak_area_norm, fe$peak_area / comp_area, tolerance = 1e-8)

  # errors when there is no scatter fitted
  d_no <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = xrf_energies(c("Fe", "Zn"), 40))
  expect_error(xrf_compton_normalize(d_no), "scatter")
})

test_that("active_thickness_um is threaded into the FP sensitivity (and thus xrf_observed_mass)", {
  # A thicker active layer catches more high-energy photons -> higher sensitivity. The effect is far larger
  # at high energy (Ba K ~32 keV, thin Si is transparent) than at low energy (Fe Ka 6.4 keV, mostly absorbed).
  s_thin  <- xrf_fp_sensitivity(c("Fe", "Ba"), 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 50)
  s_thick <- xrf_fp_sensitivity(c("Fe", "Ba"), 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 3000)
  expect_gt(s_thick$sensitivity[s_thick$element == "Ba"], s_thin$sensitivity[s_thin$element == "Ba"])
  ba_ratio <- s_thick$sensitivity[s_thick$element == "Ba"] / s_thin$sensitivity[s_thin$element == "Ba"]
  fe_ratio <- s_thick$sensitivity[s_thick$element == "Fe"] / s_thin$sensitivity[s_thin$element == "Fe"]
  expect_gt(ba_ratio, fe_ratio * 5)   # thickness bites much harder at high energy
  # NULL uses the detector preset (SDD = 450 um) -> identical to an explicit 450
  s_pre <- xrf_fp_sensitivity("Ba", 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = NULL)
  s_450 <- xrf_fp_sensitivity("Ba", 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 450)
  expect_equal(s_pre$sensitivity, s_450$sensitivity)

  # it flows through the public mass function too: thinner detector -> less sensitivity -> larger inferred mass
  pk <- data.frame(element = c("Fe", "Ba"), peak_area = c(1000, 1000))
  m_thin  <- xrf_observed_mass(pk, 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 50)
  m_thick <- xrf_observed_mass(pk, 50, detector_type = "SDD", efficiency = TRUE, active_thickness_um = 3000)
  expect_gt(m_thin$observed_mass[m_thin$element == "Ba"], m_thick$observed_mass[m_thick$element == "Ba"])
})

test_that("sensitivity_rel_se folds the FP systematic uncertainty into the SE in quadrature (item 1)", {
  sig <- function(E) xrf_detector_sigma_kev(E, "SDD"); e <- seq(2, 16, 0.03)
  y <- xrftools:::gaussian_fun(e, 6.4, sig(6.4), 400) + xrftools:::gaussian_fun(e, 3.69, sig(3.69), 250) + 10
  f <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = xrf_energies(c("Fe", "Ca"), 20),
                                              detector_type = "SDD")
  o0 <- xrf_observed_mass(f, beam_energy_kev = 20, detector_type = "SDD")
  o5 <- xrf_observed_mass(f, beam_energy_kev = 20, detector_type = "SDD", sensitivity_rel_se = 0.05)
  fe <- o0$element == "Fe"
  # exact quadrature combination of statistical (area) and systematic (sensitivity) relative errors
  expect_equal(o5$observed_mass_se[fe],
               sqrt(o0$observed_mass_se[fe]^2 + (o0$observed_mass[fe] * 0.05)^2), tolerance = 1e-8)
  expect_gt(o5$observed_mass_se[fe], o0$observed_mass_se[fe])
  # default (0) is unchanged
  expect_equal(o0$observed_mass_se,
               xrf_observed_mass(f, beam_energy_kev = 20, detector_type = "SDD",
                                 sensitivity_rel_se = 0)$observed_mass_se)
  # a named per-element vector applies per element (unnamed -> 0)
  on <- xrf_observed_mass(f, beam_energy_kev = 20, detector_type = "SDD",
                          sensitivity_rel_se = c(Fe = 0.02, Ca = 0.10))
  ca <- o0$element == "Ca"
  expect_equal(on$observed_mass_se[ca],
               sqrt(o0$observed_mass_se[ca]^2 + (o0$observed_mass[ca] * 0.10)^2), tolerance = 1e-8)
  # and it flows through xrf_quantify's concentration_se too
  c5 <- xrf_quantify(f, beam_energy_kev = 20, detector_type = "SDD", sensitivity_rel_se = 0.05)
  c0 <- xrf_quantify(f, beam_energy_kev = 20, detector_type = "SDD")
  expect_gt(c5$concentration_se[c5$element == "Fe"], c0$concentration_se[c0$element == "Fe"])
})

test_that("fp sensitivity is paired to the fitted primary line, incl. under a tube (P2)", {
  tb <- xrf_tube("Rh", kv = 50)

  # Default (no target) now selects the TEMPLATE-consistent line even in poly mode: Ba's fit templates
  # at 50 kV rank Kalpha first (mono production), so the tube-mode sensitivity must be for Kalpha too --
  # the old poly argmax picked Lalpha (4.47 keV) and mis-paired the fit's Kalpha area ~100x.
  s_def <- xrf_fp_sensitivity("Ba", 50, detector_type = "SDD", tube = tb)
  expect_equal(s_def$primary_energy_kev, 32.193, tolerance = 1e-3)
  expect_equal(s_def$primary_shell, "K")

  # Explicit pairing: ask for the Lalpha-line sensitivity instead; it is a different line with a far
  # larger tube-mode sensitivity (the L shell is excited by the whole spectrum, K only near the endpoint).
  s_ka <- xrf_fp_sensitivity("Ba", 50, detector_type = "SDD", tube = tb, primary_energy_kev = 32.193)
  s_la <- xrf_fp_sensitivity("Ba", 50, detector_type = "SDD", tube = tb, primary_energy_kev = 4.466)
  expect_equal(s_ka$primary_energy_kev, 32.193, tolerance = 1e-3)
  expect_equal(s_la$primary_energy_kev, 4.466, tolerance = 1e-3)
  expect_equal(s_la$primary_shell, "L3")
  expect_gt(s_la$sensitivity, 10 * s_ka$sensitivity)
  expect_equal(s_def$sensitivity, s_ka$sensitivity)          # default == the Kalpha pairing

  # Doublet robustness: a gain-shifted centroid between Kalpha2 (31.82) and Kalpha1 (32.19) must still
  # match the STRONGER Kalpha1 (nearest-line alone would snap to Kalpha2, halving the sensitivity).
  s_shift <- xrf_fp_sensitivity("Ba", 50, detector_type = "SDD", tube = tb, primary_energy_kev = 31.9)
  expect_equal(s_shift$primary_energy_kev, 32.193, tolerance = 1e-3)

  # A named vector matches by element symbol regardless of order.
  s_nm <- xrf_fp_sensitivity(c("Fe", "Ba"), 50, detector_type = "SDD", tube = tb,
                             primary_energy_kev = c(Ba = 4.466, Fe = 6.404))
  expect_equal(s_nm$primary_energy_kev[s_nm$element == "Ba"], 4.466, tolerance = 1e-3)
  expect_equal(s_nm$primary_energy_kev[s_nm$element == "Fe"], 6.404, tolerance = 1e-3)

  # An unexcitable fitted line (Ba Kalpha with a 30 keV beam: K edge 37.4 > 30) must be refused with a
  # warning and an NA sensitivity -- not silently quantified with a different line's sensitivity.
  expect_warning(s_bad <- xrf_fp_sensitivity("Ba", 30, detector_type = "SDD",
                                             primary_energy_kev = 32.193),
                 "primary_energy_kev")
  expect_true(is.na(s_bad$sensitivity))

  # Mono + no target is byte-identical to the historic behaviour (rank == value ranking).
  s_mono <- xrf_fp_sensitivity(c("Fe", "Sr"), 40, detector_type = "SDD")
  expect_equal(s_mono$primary_energy_kev, c(6.404006, 14.165201), tolerance = 1e-4)
})

test_that("xrf_quantify / xrf_observed_mass pass the fit's primary line through to the sensitivity (P2)", {
  tb <- xrf_tube("Rh", kv = 50)
  # a fit-shaped peaks table: the deconvolution measured Ba on Kalpha (32.19 keV) and Fe on Kalpha
  pk_fit <- data.frame(element = c("Ba", "Fe"), peak_area = c(10, 10),
                       primary_energy_kev = c(32.193, 6.404))
  q <- xrf_quantify(pk_fit, 50, detector_type = "SDD", tube = tb, self_absorption = FALSE)
  # the fitted line is preserved (not overwritten by a poly re-ranking to Lalpha at 4.47 keV)
  expect_equal(q$primary_energy_kev[q$element == "Ba"], 32.193, tolerance = 1e-3)

  # the same areas tagged as measured on Lalpha quantify very differently -- the pairing drives the result
  pk_la <- data.frame(element = c("Ba", "Fe"), peak_area = c(10, 10),
                      primary_energy_kev = c(4.466, 6.404))
  q_la <- xrf_quantify(pk_la, 50, detector_type = "SDD", tube = tb, self_absorption = FALSE)
  expect_gt(q$concentration[q$element == "Ba"] / q$concentration[q$element == "Fe"],
            10 * q_la$concentration[q_la$element == "Ba"] / q_la$concentration[q_la$element == "Fe"])

  # observed_mass: same pairing, and the Kalpha-measured area implies far more Ba than the Lalpha one
  m_ka <- xrf_observed_mass(pk_fit, 50, detector_type = "SDD", tube = tb)
  m_la <- xrf_observed_mass(pk_la, 50, detector_type = "SDD", tube = tb)
  expect_equal(m_ka$primary_energy_kev[m_ka$element == "Ba"], 32.193, tolerance = 1e-3)
  expect_gt(m_ka$observed_mass[m_ka$element == "Ba"], 10 * m_la$observed_mass[m_la$element == "Ba"])

  # end-to-end: a real fit's peaks carry primary_energy_kev, so tube-mode quantify pairs automatically
  e <- seq(2, 45, 0.02)
  pk <- xrf_energies(c("Ba", "Fe"), 50)
  sig <- xrf_detector_sigma_kev(pk$energy_kev, "SDD")
  y <- rep(0, length(e))
  for (i in seq_len(nrow(pk))) {
    y <- y + pk$relative_peak_intensity[i] / sig[i] * exp(-0.5 * ((e - pk$energy_kev[i]) / sig[i])^2)
  }
  fit <- xrf_deconvolute_gaussian_least_squares(e, y, peaks = pk, detector_type = "SDD")
  expect_equal(fit$peaks$primary_energy_kev[fit$peaks$element == "Ba"], 32.193, tolerance = 1e-3)
  qf <- xrf_quantify(fit, 50, detector_type = "SDD", tube = tb, self_absorption = FALSE)
  expect_equal(qf$primary_energy_kev[qf$element == "Ba"], 32.193, tolerance = 1e-3)
})

test_that("tube continuum follows the full Ebel (1999) depth model (P1)", {
  # Shape lock, normalized at 10 keV: values from the reference Ebel formulas (A/Z prefactor,
  # J = 0.0135*Z, energy-dependent rhoz = rhozmax*p1/p2 via the backscatter factor eta, and
  # PHOTOELECTRIC anode attenuation), verified to machine precision against PyMCA's XRayTubeEbel.py.
  # The pre-fix model (constant max depth, no A/Z, J = 0.0115*Z, total mu) gave 1.29 at 3 keV --
  # a ~2x-too-absorbed soft continuum that biased every polychromatic FP sensitivity.
  g <- c(3, 10, 20, 40)
  N <- xrf_tube_spectrum(xrf_tube("Rh", kv = 45), g, char_peak_ratio = 0, filter = FALSE)
  expect_equal(N / N[2], c(2.29501956, 1, 0.41750032, 0.04313488), tolerance = 1e-6)

  # the mean depth -> 0 at the endpoint, so the escape factor -> 1 (no self-absorption there)
  e <- seq(1, 44.9, 0.1)
  Ne <- xrf_tube_spectrum(xrf_tube("Rh", kv = 45), e, char_peak_ratio = 0, filter = FALSE)
  expect_true(all(is.finite(Ne)) && all(Ne >= 0))

  # electron incidence angle: shallower incidence deposits shallower -> LESS self-absorption of the
  # soft continuum; 90 degrees (normal) is the default and matches an omitted argument
  n90 <- xrf_tube_spectrum(xrf_tube("Rh", kv = 45), g, char_peak_ratio = 0, filter = FALSE)
  n90b <- xrf_tube_spectrum(xrf_tube("Rh", kv = 45), g, electron_incidence_deg = 90,
                            char_peak_ratio = 0, filter = FALSE)
  n70 <- xrf_tube_spectrum(xrf_tube("Rh", kv = 45), g, electron_incidence_deg = 70,
                           char_peak_ratio = 0, filter = FALSE)
  expect_identical(n90, n90b)
  expect_gt(n70[1] / n90[1], 1)                       # less soft-end absorption at 70 deg
  expect_lt(abs(n70[4] / n90[4] - 1), abs(n70[1] / n90[1] - 1))  # effect largest at the soft end

  # anode characteristic lines ride on the corrected continuum (shared helper): still tower over it
  e2 <- seq(1, 40, 0.1)
  N2 <- xrf_tube_spectrum(xrf_tube("Rh", kv = 40, filter = "Al 50"), e2)
  expect_gt(N2[which.min(abs(e2 - 20.2))], 5 * N2[which.min(abs(e2 - 15))])
})

test_that("Ebel characteristic lines carry absolute K/L fluxes (P3)", {
  ch <- xrf_tube_spectrum(xrf_tube("Rh", kv = 40), 1, discrete_lines = TRUE)
  ka <- sum(ch$flux[abs(ch$energy_kev - 20.2) < 0.3])
  kb <- sum(ch$flux[abs(ch$energy_kev - 22.8) < 0.5])
  expect_gt(ka / kb, 4); expect_lt(ka / kb, 8)          # Ka/Kb ~ 5-6 (Ebel + EADL branching)
  expect_true(any(ch$energy_kev < 4))                   # anode L series present (unfiltered)
  # W at 50 kV: K edge (69.5) unreachable -> L series only
  chw <- xrf_tube_spectrum(xrf_tube("W", kv = 50), 1, discrete_lines = TRUE)
  expect_true(all(chw$energy_kev < 12))
  # char_peak_ratio = 0 removes the lines; 2 doubles the (now physical) fluxes
  expect_equal(nrow(xrf_tube_spectrum(xrf_tube("Rh", kv = 40), 1, discrete_lines = TRUE,
                                      char_peak_ratio = 0)), 0)
  ch2 <- xrf_tube_spectrum(xrf_tube("Rh", kv = 40), 1, discrete_lines = TRUE, char_peak_ratio = 2)
  expect_equal(ch2$flux, 2 * ch$flux, tolerance = 1e-12)
  # a Be exit window mainly suppresses the L series (tube$filter models the window)
  chb <- xrf_tube_spectrum(xrf_tube("Rh", kv = 40, filter = "Be 300"), 1, discrete_lines = TRUE)
  l_cut <- sum(chb$flux[chb$energy_kev < 4]) / sum(ch$flux[ch$energy_kev < 4])
  k_cut <- sum(chb$flux[chb$energy_kev > 15]) / sum(ch$flux[ch$energy_kev > 15])
  expect_lt(l_cut, k_cut / 3)                        # window bites the L series far harder than K
  expect_lt(l_cut, 0.3); expect_gt(k_cut, 0.9)
})

test_that("poly fp sensitivity applies the M super-Coster-Kronig cascade (P5)", {
  tb <- xrf_tube("W", kv = 12)
  s_on  <- xrf_fp_sensitivity("Au", 12, detector_type = "SDD-windowless", tube = tb,
                              primary_energy_kev = 2.1229)
  s_off <- xrf_fp_sensitivity("Au", 12, detector_type = "SDD-windowless", tube = tb,
                              primary_energy_kev = 2.1229, m_cascade = FALSE)
  expect_gt(s_on$sensitivity / s_off$sensitivity, 1.2)   # super-CK transfer boosts M4/M5 production
})

test_that("secondary fluorescence includes Kbeta-only exciter lines (P6: Cu -> Ni)", {
  # Cu Kalpha (8.05 keV) is BELOW the Ni K edge (8.33) but Cu Kbeta (8.90) is above: a
  # primary-line-only model reports zero Cu -> Ni enhancement; the per-line model must not.
  pk <- data.frame(element = c("Ni", "Cu"), peak_area = c(100, 900))
  q_no  <- xrf_quantify(pk, 30, detector_type = "SDD", secondary_fluorescence = FALSE)
  q_sec <- xrf_quantify(pk, 30, detector_type = "SDD", secondary_fluorescence = TRUE)
  expect_lt(q_sec$concentration[q_sec$element == "Ni"],
            0.99 * q_no$concentration[q_no$element == "Ni"])
  # and the standard Fe -> Cr enhancement still applies strongly
  pk2 <- data.frame(element = c("Cr", "Fe"), peak_area = c(30, 950))
  q2n <- xrf_quantify(pk2, 30, detector_type = "SDD", secondary_fluorescence = FALSE)
  q2s <- xrf_quantify(pk2, 30, detector_type = "SDD", secondary_fluorescence = TRUE)
  expect_lt(q2s$concentration[1], 0.7 * q2n$concentration[1])
})
