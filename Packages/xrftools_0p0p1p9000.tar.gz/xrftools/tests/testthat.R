library(testthat)
library(xrftools)

test_check("xrftools")
